#include "rfu.h"
#include "mainwindow.h"
#include "ui_rfu.h"

extern MainWindow *mainAppWin;
rfu::rfu(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::rfu)
{
    ui->setupUi(this);
    displayUPdata = new QTimer(this);
    connect(displayUPdata, SIGNAL(timeout()),this, SLOT(update()));
    displayUPdata->start(100);
}

rfu::~rfu()
{
    delete ui;
}

void rfu::update()
{
    processHarnessDiDO();
    if(mainAppWin->startSendData == 1 && mainAppWin->unitStatus == 4)
    {
        //processContinutyProcess();
        mainAppWin->modbusCommObj->sendDoAoData(DI_TRANS_ID,4, rfuDoval);
        qDebug()<<"done";
    }
}

int rfu::checkCorrectHarness()
{
    int value1= mainAppWin->modbusCommObj->getDiValue(HARNESS_RFU_CHK_DI1);
    return (value1);
}

void rfu::processHarnessDiDO()
{
    if(checkCorrectHarness() == 1 && ui->ckHarnessContinutyError->isChecked() != 1)
    {
        setRegisterHIgh(HARNESS_RFU_CHK_DO1, 1);
        //rfuDoval[1]  = mainAppWin->modbusCommObj->setBitHigh(rfuDoval[1],(HARNESS_RFU_CHK_DO1),1);
        qDebug()<<"rfuDoval[1] = "<<rfuDoval[1];
        ui->lblHarness->setStyleSheet("QLabel { color : white; background-color : rgb(73, 202, 66); border-radius:5px;}");
        ui->lblHarnessLED->setStyleSheet("QLabel { color : white; background-color : rgb(73, 202, 66); border-radius:15px;}");
    }
    else if(checkCorrectHarness() == 1 && ui->ckHarnessContinutyError->isChecked() == 1)
    {
        setRegisterHIgh(HARNESS_RFU_CHK_DO1, 0);
        //rfuDoval[0]  = mainAppWin->modbusCommObj->setBitHigh(rfuDoval[0],(HARNESS_RFU_CHK_DO1),0);
        ui->lblHarness->setStyleSheet("QLabel { color : white; background-color : rgb(73, 202, 66); border-radius:5px;}");
        ui->lblHarnessLED->setStyleSheet("QLabel { color : white; background-color : rgb(73, 202, 66); border-radius:15px;}");
    }
}


void rfu::setRegisterHIgh(int bitPosition, bool highLow)
{
    if(bitPosition > 0 && bitPosition < 16)
    {
        rfuDoval[0] = mainAppWin->modbusCommObj->setBitHigh(rfuDoval[0],bitPosition,highLow);
    }
    else if(bitPosition  >= 16 && bitPosition  <32)
    {
        rfuDoval[1] = mainAppWin->modbusCommObj->setBitHigh(rfuDoval[1],(bitPosition - 16),highLow);
    }
    else if(bitPosition  >= 32 && bitPosition  <48)
    {
        rfuDoval[2] = mainAppWin->modbusCommObj->setBitHigh(rfuDoval[2],(bitPosition - 32),highLow);
    }
    else if(bitPosition  >= 48 && bitPosition  <64)
    {
        rfuDoval[3] = mainAppWin->modbusCommObj->setBitHigh(rfuDoval[3],(bitPosition - 48),highLow);
    }
}
