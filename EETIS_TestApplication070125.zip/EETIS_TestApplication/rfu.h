#ifndef RFU_H
#define RFU_H

#include <QWidget>
#include <QTimer>


#define HARNESS_RFU_CHK_DO1        31
#define HARNESS_RFU_CHK_DI1        2

namespace Ui {
class rfu;
}

class rfu : public QWidget
{
    Q_OBJECT

public:
    explicit rfu(QWidget *parent = 0);
    ~rfu();
    short rfuDoval[4] = {0};
protected slots:
    void update();
protected:
    int checkCorrectHarness();
    void processHarnessDiDO();
    void setRegisterHIgh(int bitPosition, bool highLow );
private:
    Ui::rfu *ui;
    QTimer *displayUPdata;
};

#endif // RFU_H
