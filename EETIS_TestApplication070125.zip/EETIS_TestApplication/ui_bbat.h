/********************************************************************************
** Form generated from reading UI file 'bbat.ui'
**
** Created by: Qt User Interface Compiler version 5.9.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_BBAT_H
#define UI_BBAT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_BBAT
{
public:
    QGroupBox *groupBox_4;
    QPushButton *pbHarness_4;
    QLabel *lblBBATTJ7BtoJ7C;
    QLabel *lblBBATTJ7AJcC;
    QLabel *label_73;
    QLabel *label_41;
    QLabel *lblBBATTJ7AtoJ7B;
    QLabel *label_74;
    QDoubleSpinBox *dbsJ7aToJ7b;
    QDoubleSpinBox *dbsJ7btoJ7c;
    QDoubleSpinBox *dbsJ7aToJ7c;
    QGroupBox *groupBox_3;
    QPushButton *pbHarness_3;
    QLabel *lblPowerOn;
    QDoubleSpinBox *lblBBATTJ7AtoJ7BVoltage;
    QGroupBox *groupBox;
    QLabel *lblHarnessLED;
    QLabel *lblHarness;
    QPushButton *pbHarness;
    QLabel *label_103;
    QLabel *label_104;
    QLabel *lblOPRMODE_2;
    QGroupBox *groupBox_2;
    QLabel *ledJ2AtoJ2D;
    QLabel *lblBBATTJ2BJ2E;
    QLabel *lblBBATTJ2AJ2D_4;
    QLabel *lblBBATTJ2AJ2D_6;
    QLabel *lblBBATTJ2AJ2D_8;
    QLabel *lblBBATTJ2AJ2D_10;
    QLabel *lblBBATTJ2AJ2D_14;
    QLabel *lblBBATTJ2AJ2D_24;
    QLabel *lblBBATTJ2AJ2D_25;
    QLabel *lblBBATTJ2AJ2D_26;
    QLabel *lblBBATTJ2AJ2D_27;
    QLabel *lblBBATTJ2AJ2D_28;
    QLabel *lblBBATTJ2AJ2D_29;
    QLabel *lblBBATTJ2AJ2D_30;
    QLabel *lblBBATTJ2AJ2D_31;
    QLabel *lblBBATTJ2AJ2D_32;
    QPushButton *pbHarness_2;
    QLabel *label_107;
    QLabel *lblBBATTJ2AJ2D_33;
    QLabel *lblBBATTJ2AJ2D_36;
    QLabel *lblBBATTJ2AJ2D_40;
    QLabel *lblBBATTJ2AJ2D_42;
    QLabel *ledj2atoj2d;
    QLabel *ledJ2btoj2e;
    QLabel *ledj2ctoj2f;
    QLabel *ledj2gtoj2k;
    QLabel *ledj2htoj2l;
    QLabel *ledj2jtoj2m;
    QLabel *ledj3atoj3c;
    QLabel *ledj3btoj3d;
    QLabel *lblj4atoj4b;
    QLabel *ledj5atoj5c;
    QLabel *ledj5btoj5d;
    QLabel *ledj5ftoj5g;
    QLabel *ledj5etoj5g;
    QLabel *ledj61toj62;
    QLabel *ledj7atoj7c;
    QLabel *ledj7btoj7d;
    QLabel *ledj8ctoj8d;
    QLabel *ledj8gtoj8h;
    QLabel *ledj8atoj8b;
    QLabel *ledj8etoj8f;
    QLabel *label_109;

    void setupUi(QWidget *BBAT)
    {
        if (BBAT->objectName().isEmpty())
            BBAT->setObjectName(QStringLiteral("BBAT"));
        BBAT->resize(1900, 900);
        groupBox_4 = new QGroupBox(BBAT);
        groupBox_4->setObjectName(QStringLiteral("groupBox_4"));
        groupBox_4->setGeometry(QRect(1056, 94, 653, 155));
        groupBox_4->setStyleSheet(QLatin1String("background:color rgb(150,160,186,40%);\n"
"border-radius:10px;"));
        pbHarness_4 = new QPushButton(groupBox_4);
        pbHarness_4->setObjectName(QStringLiteral("pbHarness_4"));
        pbHarness_4->setGeometry(QRect(0, 2, 441, 41));
        QFont font;
        font.setPointSize(14);
        pbHarness_4->setFont(font);
        pbHarness_4->setStyleSheet(QLatin1String("background-color: rgb(53, 74, 131); \n"
"color: rgb(255, 255, 255);"));
        lblBBATTJ7BtoJ7C = new QLabel(groupBox_4);
        lblBBATTJ7BtoJ7C->setObjectName(QStringLiteral("lblBBATTJ7BtoJ7C"));
        lblBBATTJ7BtoJ7C->setGeometry(QRect(223, 54, 200, 40));
        QFont font1;
        font1.setFamily(QStringLiteral("Roboto"));
        font1.setPointSize(13);
        font1.setBold(true);
        font1.setWeight(75);
        lblBBATTJ7BtoJ7C->setFont(font1);
        lblBBATTJ7BtoJ7C->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBBATTJ7BtoJ7C->setAlignment(Qt::AlignCenter);
        lblBBATTJ7AJcC = new QLabel(groupBox_4);
        lblBBATTJ7AJcC->setObjectName(QStringLiteral("lblBBATTJ7AJcC"));
        lblBBATTJ7AJcC->setGeometry(QRect(438, 54, 200, 40));
        lblBBATTJ7AJcC->setFont(font1);
        lblBBATTJ7AJcC->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBBATTJ7AJcC->setAlignment(Qt::AlignCenter);
        label_73 = new QLabel(groupBox_4);
        label_73->setObjectName(QStringLiteral("label_73"));
        label_73->setGeometry(QRect(380, 110, 31, 31));
        label_73->setFont(font1);
        label_73->setStyleSheet(QLatin1String("background-color: rgb(150,160,186,1%);\n"
"color:rgb(53,74, 131);\n"
""));
        label_41 = new QLabel(groupBox_4);
        label_41->setObjectName(QStringLiteral("label_41"));
        label_41->setGeometry(QRect(160, 109, 31, 31));
        label_41->setFont(font1);
        label_41->setStyleSheet(QLatin1String("background-color: rgb(150,160,186,1%);\n"
"color:rgb(53,74, 131);\n"
""));
        lblBBATTJ7AtoJ7B = new QLabel(groupBox_4);
        lblBBATTJ7AtoJ7B->setObjectName(QStringLiteral("lblBBATTJ7AtoJ7B"));
        lblBBATTJ7AtoJ7B->setGeometry(QRect(8, 54, 200, 40));
        lblBBATTJ7AtoJ7B->setFont(font1);
        lblBBATTJ7AtoJ7B->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBBATTJ7AtoJ7B->setAlignment(Qt::AlignCenter);
        label_74 = new QLabel(groupBox_4);
        label_74->setObjectName(QStringLiteral("label_74"));
        label_74->setGeometry(QRect(590, 110, 41, 31));
        label_74->setFont(font1);
        label_74->setStyleSheet(QLatin1String("background-color: rgb(150,160,186,1%);\n"
"color:rgb(53,74, 131);\n"
""));
        dbsJ7aToJ7b = new QDoubleSpinBox(groupBox_4);
        dbsJ7aToJ7b->setObjectName(QStringLiteral("dbsJ7aToJ7b"));
        dbsJ7aToJ7b->setGeometry(QRect(58, 104, 100, 40));
        QFont font2;
        font2.setFamily(QStringLiteral("Roboto"));
        font2.setPointSize(13);
        dbsJ7aToJ7b->setFont(font2);
        dbsJ7aToJ7b->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
""));
        dbsJ7btoJ7c = new QDoubleSpinBox(groupBox_4);
        dbsJ7btoJ7c->setObjectName(QStringLiteral("dbsJ7btoJ7c"));
        dbsJ7btoJ7c->setGeometry(QRect(276, 104, 100, 40));
        dbsJ7btoJ7c->setFont(font2);
        dbsJ7btoJ7c->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
""));
        dbsJ7aToJ7c = new QDoubleSpinBox(groupBox_4);
        dbsJ7aToJ7c->setObjectName(QStringLiteral("dbsJ7aToJ7c"));
        dbsJ7aToJ7c->setGeometry(QRect(488, 104, 100, 40));
        dbsJ7aToJ7c->setFont(font2);
        dbsJ7aToJ7c->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
""));
        groupBox_3 = new QGroupBox(BBAT);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        groupBox_3->setGeometry(QRect(154, 95, 341, 155));
        groupBox_3->setStyleSheet(QLatin1String("background:color rgb(150,160,186,40%);\n"
"border-radius:10px;"));
        pbHarness_3 = new QPushButton(groupBox_3);
        pbHarness_3->setObjectName(QStringLiteral("pbHarness_3"));
        pbHarness_3->setGeometry(QRect(0, 0, 151, 41));
        pbHarness_3->setFont(font);
        pbHarness_3->setStyleSheet(QLatin1String("background-color: rgb(53, 74, 131); \n"
"color: rgb(255, 255, 255);"));
        lblPowerOn = new QLabel(groupBox_3);
        lblPowerOn->setObjectName(QStringLiteral("lblPowerOn"));
        lblPowerOn->setGeometry(QRect(60, 60, 218, 40));
        lblPowerOn->setFont(font1);
        lblPowerOn->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblPowerOn->setAlignment(Qt::AlignCenter);
        lblBBATTJ7AtoJ7BVoltage = new QDoubleSpinBox(groupBox_3);
        lblBBATTJ7AtoJ7BVoltage->setObjectName(QStringLiteral("lblBBATTJ7AtoJ7BVoltage"));
        lblBBATTJ7AtoJ7BVoltage->setGeometry(QRect(210, 10, 100, 40));
        lblBBATTJ7AtoJ7BVoltage->setFont(font1);
        lblBBATTJ7AtoJ7BVoltage->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
""));
        lblBBATTJ7AtoJ7BVoltage->setReadOnly(true);
        lblBBATTJ7AtoJ7BVoltage->setButtonSymbols(QAbstractSpinBox::NoButtons);
        lblBBATTJ7AtoJ7BVoltage->setDecimals(1);
        lblBBATTJ7AtoJ7BVoltage->setMaximum(12);
        groupBox = new QGroupBox(BBAT);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(503, 95, 545, 155));
        groupBox->setStyleSheet(QLatin1String("background:color rgb(150,160,186,40%);\n"
"border-radius:10px;"));
        lblHarnessLED = new QLabel(groupBox);
        lblHarnessLED->setObjectName(QStringLiteral("lblHarnessLED"));
        lblHarnessLED->setGeometry(QRect(359, 94, 30, 30));
        lblHarnessLED->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        lblHarness = new QLabel(groupBox);
        lblHarness->setObjectName(QStringLiteral("lblHarness"));
        lblHarness->setGeometry(QRect(106, 88, 218, 40));
        lblHarness->setFont(font1);
        lblHarness->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblHarness->setAlignment(Qt::AlignCenter);
        pbHarness = new QPushButton(groupBox);
        pbHarness->setObjectName(QStringLiteral("pbHarness"));
        pbHarness->setGeometry(QRect(0, 0, 441, 41));
        pbHarness->setFont(font);
        pbHarness->setStyleSheet(QLatin1String("background-color: rgb(53, 74, 131); \n"
"color: rgb(255, 255, 255);"));
        label_103 = new QLabel(groupBox);
        label_103->setObjectName(QStringLiteral("label_103"));
        label_103->setGeometry(QRect(210, 52, 61, 38));
        QFont font3;
        font3.setFamily(QStringLiteral("Roboto"));
        font3.setPointSize(16);
        font3.setBold(true);
        font3.setWeight(75);
        label_103->setFont(font3);
        label_103->setStyleSheet(QLatin1String("background:color rgb(150,160,186,1%);\n"
"color:rgb(53,74, 131);"));
        label_104 = new QLabel(groupBox);
        label_104->setObjectName(QStringLiteral("label_104"));
        label_104->setGeometry(QRect(334, 54, 81, 33));
        label_104->setFont(font3);
        label_104->setStyleSheet(QLatin1String("background:color rgb(150,160,186,1%);\n"
"color:rgb(53,74, 131);"));
        label_104->setAlignment(Qt::AlignCenter);
        lblOPRMODE_2 = new QLabel(BBAT);
        lblOPRMODE_2->setObjectName(QStringLiteral("lblOPRMODE_2"));
        lblOPRMODE_2->setGeometry(QRect(796, 30, 291, 55));
        QFont font4;
        font4.setFamily(QStringLiteral("Roboto"));
        font4.setPointSize(25);
        font4.setBold(true);
        font4.setUnderline(true);
        font4.setWeight(75);
        lblOPRMODE_2->setFont(font4);
        lblOPRMODE_2->setStyleSheet(QLatin1String("\n"
"background:rgb(234, 236, 247);\n"
"\n"
"\n"
"color:rgb(53,74, 131);\n"
""));
        lblOPRMODE_2->setAlignment(Qt::AlignCenter);
        groupBox_2 = new QGroupBox(BBAT);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        groupBox_2->setGeometry(QRect(155, 260, 1561, 618));
        groupBox_2->setStyleSheet(QLatin1String("background:color rgb(150,160,186,40%);\n"
"border-radius:10px;"));
        ledJ2AtoJ2D = new QLabel(groupBox_2);
        ledJ2AtoJ2D->setObjectName(QStringLiteral("ledJ2AtoJ2D"));
        ledJ2AtoJ2D->setGeometry(QRect(200, 109, 218, 40));
        ledJ2AtoJ2D->setFont(font1);
        ledJ2AtoJ2D->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        ledJ2AtoJ2D->setAlignment(Qt::AlignCenter);
        lblBBATTJ2BJ2E = new QLabel(groupBox_2);
        lblBBATTJ2BJ2E->setObjectName(QStringLiteral("lblBBATTJ2BJ2E"));
        lblBBATTJ2BJ2E->setGeometry(QRect(200, 159, 218, 40));
        lblBBATTJ2BJ2E->setFont(font1);
        lblBBATTJ2BJ2E->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBBATTJ2BJ2E->setAlignment(Qt::AlignCenter);
        lblBBATTJ2AJ2D_4 = new QLabel(groupBox_2);
        lblBBATTJ2AJ2D_4->setObjectName(QStringLiteral("lblBBATTJ2AJ2D_4"));
        lblBBATTJ2AJ2D_4->setGeometry(QRect(200, 208, 218, 40));
        lblBBATTJ2AJ2D_4->setFont(font1);
        lblBBATTJ2AJ2D_4->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBBATTJ2AJ2D_4->setAlignment(Qt::AlignCenter);
        lblBBATTJ2AJ2D_6 = new QLabel(groupBox_2);
        lblBBATTJ2AJ2D_6->setObjectName(QStringLiteral("lblBBATTJ2AJ2D_6"));
        lblBBATTJ2AJ2D_6->setGeometry(QRect(200, 358, 218, 40));
        lblBBATTJ2AJ2D_6->setFont(font1);
        lblBBATTJ2AJ2D_6->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBBATTJ2AJ2D_6->setAlignment(Qt::AlignCenter);
        lblBBATTJ2AJ2D_8 = new QLabel(groupBox_2);
        lblBBATTJ2AJ2D_8->setObjectName(QStringLiteral("lblBBATTJ2AJ2D_8"));
        lblBBATTJ2AJ2D_8->setGeometry(QRect(200, 308, 218, 40));
        lblBBATTJ2AJ2D_8->setFont(font1);
        lblBBATTJ2AJ2D_8->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBBATTJ2AJ2D_8->setAlignment(Qt::AlignCenter);
        lblBBATTJ2AJ2D_10 = new QLabel(groupBox_2);
        lblBBATTJ2AJ2D_10->setObjectName(QStringLiteral("lblBBATTJ2AJ2D_10"));
        lblBBATTJ2AJ2D_10->setGeometry(QRect(200, 258, 218, 40));
        lblBBATTJ2AJ2D_10->setFont(font1);
        lblBBATTJ2AJ2D_10->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBBATTJ2AJ2D_10->setAlignment(Qt::AlignCenter);
        lblBBATTJ2AJ2D_14 = new QLabel(groupBox_2);
        lblBBATTJ2AJ2D_14->setObjectName(QStringLiteral("lblBBATTJ2AJ2D_14"));
        lblBBATTJ2AJ2D_14->setGeometry(QRect(200, 460, 218, 40));
        lblBBATTJ2AJ2D_14->setFont(font1);
        lblBBATTJ2AJ2D_14->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBBATTJ2AJ2D_14->setAlignment(Qt::AlignCenter);
        lblBBATTJ2AJ2D_24 = new QLabel(groupBox_2);
        lblBBATTJ2AJ2D_24->setObjectName(QStringLiteral("lblBBATTJ2AJ2D_24"));
        lblBBATTJ2AJ2D_24->setGeometry(QRect(956, 460, 218, 40));
        lblBBATTJ2AJ2D_24->setFont(font1);
        lblBBATTJ2AJ2D_24->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBBATTJ2AJ2D_24->setAlignment(Qt::AlignCenter);
        lblBBATTJ2AJ2D_25 = new QLabel(groupBox_2);
        lblBBATTJ2AJ2D_25->setObjectName(QStringLiteral("lblBBATTJ2AJ2D_25"));
        lblBBATTJ2AJ2D_25->setGeometry(QRect(956, 410, 218, 40));
        lblBBATTJ2AJ2D_25->setFont(font1);
        lblBBATTJ2AJ2D_25->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBBATTJ2AJ2D_25->setAlignment(Qt::AlignCenter);
        lblBBATTJ2AJ2D_26 = new QLabel(groupBox_2);
        lblBBATTJ2AJ2D_26->setObjectName(QStringLiteral("lblBBATTJ2AJ2D_26"));
        lblBBATTJ2AJ2D_26->setGeometry(QRect(200, 410, 218, 40));
        lblBBATTJ2AJ2D_26->setFont(font1);
        lblBBATTJ2AJ2D_26->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBBATTJ2AJ2D_26->setAlignment(Qt::AlignCenter);
        lblBBATTJ2AJ2D_27 = new QLabel(groupBox_2);
        lblBBATTJ2AJ2D_27->setObjectName(QStringLiteral("lblBBATTJ2AJ2D_27"));
        lblBBATTJ2AJ2D_27->setGeometry(QRect(956, 358, 218, 40));
        lblBBATTJ2AJ2D_27->setFont(font1);
        lblBBATTJ2AJ2D_27->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBBATTJ2AJ2D_27->setAlignment(Qt::AlignCenter);
        lblBBATTJ2AJ2D_28 = new QLabel(groupBox_2);
        lblBBATTJ2AJ2D_28->setObjectName(QStringLiteral("lblBBATTJ2AJ2D_28"));
        lblBBATTJ2AJ2D_28->setGeometry(QRect(956, 308, 218, 40));
        lblBBATTJ2AJ2D_28->setFont(font1);
        lblBBATTJ2AJ2D_28->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBBATTJ2AJ2D_28->setAlignment(Qt::AlignCenter);
        lblBBATTJ2AJ2D_29 = new QLabel(groupBox_2);
        lblBBATTJ2AJ2D_29->setObjectName(QStringLiteral("lblBBATTJ2AJ2D_29"));
        lblBBATTJ2AJ2D_29->setGeometry(QRect(956, 258, 218, 40));
        lblBBATTJ2AJ2D_29->setFont(font1);
        lblBBATTJ2AJ2D_29->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBBATTJ2AJ2D_29->setAlignment(Qt::AlignCenter);
        lblBBATTJ2AJ2D_30 = new QLabel(groupBox_2);
        lblBBATTJ2AJ2D_30->setObjectName(QStringLiteral("lblBBATTJ2AJ2D_30"));
        lblBBATTJ2AJ2D_30->setGeometry(QRect(956, 208, 218, 40));
        lblBBATTJ2AJ2D_30->setFont(font1);
        lblBBATTJ2AJ2D_30->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBBATTJ2AJ2D_30->setAlignment(Qt::AlignCenter);
        lblBBATTJ2AJ2D_31 = new QLabel(groupBox_2);
        lblBBATTJ2AJ2D_31->setObjectName(QStringLiteral("lblBBATTJ2AJ2D_31"));
        lblBBATTJ2AJ2D_31->setGeometry(QRect(956, 159, 218, 40));
        lblBBATTJ2AJ2D_31->setFont(font1);
        lblBBATTJ2AJ2D_31->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBBATTJ2AJ2D_31->setAlignment(Qt::AlignCenter);
        lblBBATTJ2AJ2D_32 = new QLabel(groupBox_2);
        lblBBATTJ2AJ2D_32->setObjectName(QStringLiteral("lblBBATTJ2AJ2D_32"));
        lblBBATTJ2AJ2D_32->setGeometry(QRect(956, 109, 218, 40));
        lblBBATTJ2AJ2D_32->setFont(font1);
        lblBBATTJ2AJ2D_32->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBBATTJ2AJ2D_32->setAlignment(Qt::AlignCenter);
        pbHarness_2 = new QPushButton(groupBox_2);
        pbHarness_2->setObjectName(QStringLiteral("pbHarness_2"));
        pbHarness_2->setGeometry(QRect(0, 0, 441, 41));
        pbHarness_2->setFont(font);
        pbHarness_2->setStyleSheet(QLatin1String("background-color: rgb(53, 74, 131); \n"
"color: rgb(255, 255, 255);"));
        label_107 = new QLabel(groupBox_2);
        label_107->setObjectName(QStringLiteral("label_107"));
        label_107->setGeometry(QRect(509, 54, 61, 38));
        label_107->setFont(font3);
        label_107->setStyleSheet(QLatin1String("background:color rgb(150,160,186,1%);\n"
"color:rgb(53,74, 131);"));
        lblBBATTJ2AJ2D_33 = new QLabel(groupBox_2);
        lblBBATTJ2AJ2D_33->setObjectName(QStringLiteral("lblBBATTJ2AJ2D_33"));
        lblBBATTJ2AJ2D_33->setGeometry(QRect(200, 510, 218, 40));
        lblBBATTJ2AJ2D_33->setFont(font1);
        lblBBATTJ2AJ2D_33->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBBATTJ2AJ2D_33->setAlignment(Qt::AlignCenter);
        lblBBATTJ2AJ2D_36 = new QLabel(groupBox_2);
        lblBBATTJ2AJ2D_36->setObjectName(QStringLiteral("lblBBATTJ2AJ2D_36"));
        lblBBATTJ2AJ2D_36->setGeometry(QRect(200, 560, 218, 40));
        lblBBATTJ2AJ2D_36->setFont(font1);
        lblBBATTJ2AJ2D_36->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBBATTJ2AJ2D_36->setAlignment(Qt::AlignCenter);
        lblBBATTJ2AJ2D_40 = new QLabel(groupBox_2);
        lblBBATTJ2AJ2D_40->setObjectName(QStringLiteral("lblBBATTJ2AJ2D_40"));
        lblBBATTJ2AJ2D_40->setGeometry(QRect(956, 510, 218, 40));
        lblBBATTJ2AJ2D_40->setFont(font1);
        lblBBATTJ2AJ2D_40->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBBATTJ2AJ2D_40->setAlignment(Qt::AlignCenter);
        lblBBATTJ2AJ2D_42 = new QLabel(groupBox_2);
        lblBBATTJ2AJ2D_42->setObjectName(QStringLiteral("lblBBATTJ2AJ2D_42"));
        lblBBATTJ2AJ2D_42->setGeometry(QRect(956, 560, 218, 40));
        lblBBATTJ2AJ2D_42->setFont(font1);
        lblBBATTJ2AJ2D_42->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBBATTJ2AJ2D_42->setAlignment(Qt::AlignCenter);
        ledj2atoj2d = new QLabel(groupBox_2);
        ledj2atoj2d->setObjectName(QStringLiteral("ledj2atoj2d"));
        ledj2atoj2d->setGeometry(QRect(524, 108, 30, 30));
        ledj2atoj2d->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        ledJ2btoj2e = new QLabel(groupBox_2);
        ledJ2btoj2e->setObjectName(QStringLiteral("ledJ2btoj2e"));
        ledJ2btoj2e->setGeometry(QRect(1300, 114, 30, 30));
        ledJ2btoj2e->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        ledj2ctoj2f = new QLabel(groupBox_2);
        ledj2ctoj2f->setObjectName(QStringLiteral("ledj2ctoj2f"));
        ledj2ctoj2f->setGeometry(QRect(524, 164, 30, 30));
        ledj2ctoj2f->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        ledj2gtoj2k = new QLabel(groupBox_2);
        ledj2gtoj2k->setObjectName(QStringLiteral("ledj2gtoj2k"));
        ledj2gtoj2k->setGeometry(QRect(1300, 164, 30, 30));
        ledj2gtoj2k->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        ledj2htoj2l = new QLabel(groupBox_2);
        ledj2htoj2l->setObjectName(QStringLiteral("ledj2htoj2l"));
        ledj2htoj2l->setGeometry(QRect(524, 213, 30, 30));
        ledj2htoj2l->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        ledj2jtoj2m = new QLabel(groupBox_2);
        ledj2jtoj2m->setObjectName(QStringLiteral("ledj2jtoj2m"));
        ledj2jtoj2m->setGeometry(QRect(1300, 213, 30, 30));
        ledj2jtoj2m->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        ledj3atoj3c = new QLabel(groupBox_2);
        ledj3atoj3c->setObjectName(QStringLiteral("ledj3atoj3c"));
        ledj3atoj3c->setGeometry(QRect(524, 263, 30, 30));
        ledj3atoj3c->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        ledj3btoj3d = new QLabel(groupBox_2);
        ledj3btoj3d->setObjectName(QStringLiteral("ledj3btoj3d"));
        ledj3btoj3d->setGeometry(QRect(1300, 263, 30, 30));
        ledj3btoj3d->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        lblj4atoj4b = new QLabel(groupBox_2);
        lblj4atoj4b->setObjectName(QStringLiteral("lblj4atoj4b"));
        lblj4atoj4b->setGeometry(QRect(524, 313, 30, 30));
        lblj4atoj4b->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        ledj5atoj5c = new QLabel(groupBox_2);
        ledj5atoj5c->setObjectName(QStringLiteral("ledj5atoj5c"));
        ledj5atoj5c->setGeometry(QRect(1300, 313, 30, 30));
        ledj5atoj5c->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        ledj5btoj5d = new QLabel(groupBox_2);
        ledj5btoj5d->setObjectName(QStringLiteral("ledj5btoj5d"));
        ledj5btoj5d->setGeometry(QRect(524, 363, 30, 30));
        ledj5btoj5d->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        ledj5ftoj5g = new QLabel(groupBox_2);
        ledj5ftoj5g->setObjectName(QStringLiteral("ledj5ftoj5g"));
        ledj5ftoj5g->setGeometry(QRect(1300, 363, 30, 30));
        ledj5ftoj5g->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        ledj5etoj5g = new QLabel(groupBox_2);
        ledj5etoj5g->setObjectName(QStringLiteral("ledj5etoj5g"));
        ledj5etoj5g->setGeometry(QRect(524, 415, 30, 30));
        ledj5etoj5g->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        ledj61toj62 = new QLabel(groupBox_2);
        ledj61toj62->setObjectName(QStringLiteral("ledj61toj62"));
        ledj61toj62->setGeometry(QRect(1300, 415, 30, 30));
        ledj61toj62->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        ledj7atoj7c = new QLabel(groupBox_2);
        ledj7atoj7c->setObjectName(QStringLiteral("ledj7atoj7c"));
        ledj7atoj7c->setGeometry(QRect(524, 465, 30, 30));
        ledj7atoj7c->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        ledj7btoj7d = new QLabel(groupBox_2);
        ledj7btoj7d->setObjectName(QStringLiteral("ledj7btoj7d"));
        ledj7btoj7d->setGeometry(QRect(1300, 465, 30, 30));
        ledj7btoj7d->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        ledj8ctoj8d = new QLabel(groupBox_2);
        ledj8ctoj8d->setObjectName(QStringLiteral("ledj8ctoj8d"));
        ledj8ctoj8d->setGeometry(QRect(524, 515, 30, 30));
        ledj8ctoj8d->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        ledj8gtoj8h = new QLabel(groupBox_2);
        ledj8gtoj8h->setObjectName(QStringLiteral("ledj8gtoj8h"));
        ledj8gtoj8h->setGeometry(QRect(1300, 515, 30, 30));
        ledj8gtoj8h->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        ledj8atoj8b = new QLabel(groupBox_2);
        ledj8atoj8b->setObjectName(QStringLiteral("ledj8atoj8b"));
        ledj8atoj8b->setGeometry(QRect(524, 565, 30, 30));
        ledj8atoj8b->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        ledj8etoj8f = new QLabel(groupBox_2);
        ledj8etoj8f->setObjectName(QStringLiteral("ledj8etoj8f"));
        ledj8etoj8f->setGeometry(QRect(1300, 565, 30, 30));
        ledj8etoj8f->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        label_109 = new QLabel(groupBox_2);
        label_109->setObjectName(QStringLiteral("label_109"));
        label_109->setGeometry(QRect(1283, 54, 61, 38));
        label_109->setFont(font3);
        label_109->setStyleSheet(QLatin1String("background:color rgb(150,160,186,1%);\n"
"color:rgb(53,74, 131);"));

        retranslateUi(BBAT);

        QMetaObject::connectSlotsByName(BBAT);
    } // setupUi

    void retranslateUi(QWidget *BBAT)
    {
        BBAT->setWindowTitle(QApplication::translate("BBAT", "Form", Q_NULLPTR));
        groupBox_4->setTitle(QString());
        pbHarness_4->setText(QApplication::translate("BBAT", "Battery Voltage Check", Q_NULLPTR));
        lblBBATTJ7BtoJ7C->setText(QApplication::translate("BBAT", "J7-B to J7-C", Q_NULLPTR));
        lblBBATTJ7AJcC->setText(QApplication::translate("BBAT", "J7-A to J7-C", Q_NULLPTR));
        label_73->setText(QApplication::translate("BBAT", "V", Q_NULLPTR));
        label_41->setText(QApplication::translate("BBAT", "V", Q_NULLPTR));
        lblBBATTJ7AtoJ7B->setText(QApplication::translate("BBAT", "J7-A to J7-B", Q_NULLPTR));
        label_74->setText(QApplication::translate("BBAT", "V", Q_NULLPTR));
        groupBox_3->setTitle(QString());
        pbHarness_3->setText(QString());
        lblPowerOn->setText(QApplication::translate("BBAT", "Power on", Q_NULLPTR));
        groupBox->setTitle(QString());
        lblHarnessLED->setText(QString());
        lblHarness->setText(QApplication::translate("BBAT", "Harness", Q_NULLPTR));
        pbHarness->setText(QApplication::translate("BBAT", "BBAT harness check connection", Q_NULLPTR));
        label_103->setText(QApplication::translate("BBAT", "DI's", Q_NULLPTR));
        label_104->setText(QApplication::translate("BBAT", "DO's", Q_NULLPTR));
        lblOPRMODE_2->setText(QApplication::translate("BBAT", "BBAT", Q_NULLPTR));
        groupBox_2->setTitle(QString());
        ledJ2AtoJ2D->setText(QApplication::translate("BBAT", "J2-A to J2-D", Q_NULLPTR));
        lblBBATTJ2BJ2E->setText(QApplication::translate("BBAT", "J2-C to J2-F", Q_NULLPTR));
        lblBBATTJ2AJ2D_4->setText(QApplication::translate("BBAT", "J2- H to J2-L", Q_NULLPTR));
        lblBBATTJ2AJ2D_6->setText(QApplication::translate("BBAT", "J5- B to J5-D", Q_NULLPTR));
        lblBBATTJ2AJ2D_8->setText(QApplication::translate("BBAT", "J4-A to J4-B", Q_NULLPTR));
        lblBBATTJ2AJ2D_10->setText(QApplication::translate("BBAT", "J3-A to J3-C", Q_NULLPTR));
        lblBBATTJ2AJ2D_14->setText(QApplication::translate("BBAT", "J7-A to J7-C", Q_NULLPTR));
        lblBBATTJ2AJ2D_24->setText(QApplication::translate("BBAT", "J7-B to J7-D", Q_NULLPTR));
        lblBBATTJ2AJ2D_25->setText(QApplication::translate("BBAT", "J6-1 to J6-2", Q_NULLPTR));
        lblBBATTJ2AJ2D_26->setText(QApplication::translate("BBAT", "J5-E to J5-G", Q_NULLPTR));
        lblBBATTJ2AJ2D_27->setText(QApplication::translate("BBAT", "J5-F to J5-G", Q_NULLPTR));
        lblBBATTJ2AJ2D_28->setText(QApplication::translate("BBAT", "J5-A to J5-C", Q_NULLPTR));
        lblBBATTJ2AJ2D_29->setText(QApplication::translate("BBAT", "J3-B to J3-D", Q_NULLPTR));
        lblBBATTJ2AJ2D_30->setText(QApplication::translate("BBAT", "J2-J to J2-M", Q_NULLPTR));
        lblBBATTJ2AJ2D_31->setText(QApplication::translate("BBAT", "J2-G to J2-K", Q_NULLPTR));
        lblBBATTJ2AJ2D_32->setText(QApplication::translate("BBAT", "J2-B to J2-E", Q_NULLPTR));
        pbHarness_2->setText(QApplication::translate("BBAT", "Test", Q_NULLPTR));
        label_107->setText(QApplication::translate("BBAT", "DO's", Q_NULLPTR));
        lblBBATTJ2AJ2D_33->setText(QApplication::translate("BBAT", "J8-C to J8-D", Q_NULLPTR));
        lblBBATTJ2AJ2D_36->setText(QApplication::translate("BBAT", "J8-A to J8-B", Q_NULLPTR));
        lblBBATTJ2AJ2D_40->setText(QApplication::translate("BBAT", "J8-G to J8-H", Q_NULLPTR));
        lblBBATTJ2AJ2D_42->setText(QApplication::translate("BBAT", "J8-E to J8-F", Q_NULLPTR));
        ledj2atoj2d->setText(QString());
        ledJ2btoj2e->setText(QString());
        ledj2ctoj2f->setText(QString());
        ledj2gtoj2k->setText(QString());
        ledj2htoj2l->setText(QString());
        ledj2jtoj2m->setText(QString());
        ledj3atoj3c->setText(QString());
        ledj3btoj3d->setText(QString());
        lblj4atoj4b->setText(QString());
        ledj5atoj5c->setText(QString());
        ledj5btoj5d->setText(QString());
        ledj5ftoj5g->setText(QString());
        ledj5etoj5g->setText(QString());
        ledj61toj62->setText(QString());
        ledj7atoj7c->setText(QString());
        ledj7btoj7d->setText(QString());
        ledj8ctoj8d->setText(QString());
        ledj8gtoj8h->setText(QString());
        ledj8atoj8b->setText(QString());
        ledj8etoj8f->setText(QString());
        label_109->setText(QApplication::translate("BBAT", "DO's", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class BBAT: public Ui_BBAT {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_BBAT_H
