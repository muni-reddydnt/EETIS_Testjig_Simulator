/********************************************************************************
** Form generated from reading UI file 'bdobus.ui'
**
** Created by: Qt User Interface Compiler version 5.9.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_BDOBUS_H
#define UI_BDOBUS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_bdobus
{
public:
    QWidget *widget_14;
    QLabel *lblBDOBUSJ17J21LED;
    QLabel *lblBDOBUSJ19J23LED;
    QLabel *lblBDOBUSJ110J24LED;
    QLabel *lblBDOBUSJ112J26LED;
    QLabel *lblBDOBUSJ114J28LED;
    QLabel *lblBDOBUSJ18J22LED;
    QLabel *lblBDOBUSJ19J110LED;
    QLabel *lblBDOBUSJ111J25LED;
    QLabel *lblBDOBUSJ113J27LED;
    QLabel *lblBDOBUSJ115J29LED;
    QLabel *lblShellLoadingLED;
    QLabel *lblEmergencyStopLED;
    QCheckBox *ckBDOBUSJ17J21;
    QCheckBox *ckBDOBUSJ19J23;
    QCheckBox *ckBDOBUSJ110J24;
    QCheckBox *ckBDOBUSJ112J26;
    QCheckBox *ckBDOBUSJ114J28;
    QCheckBox *ckShellLoading;
    QCheckBox *ckCrossBDOBUSJ17J21;
    QCheckBox *ckCrossBDOBUSJ19J23;
    QCheckBox *ckCrossBDOBUSJ110J24;
    QCheckBox *ckCrossBDOBUSJ112J26;
    QCheckBox *ckCrossBDOBUSJ114J28;
    QCheckBox *ckCrossShellLoading;
    QCheckBox *ckCrossBDOBUSJ18J22;
    QCheckBox *ckBDOBUSJ18J22;
    QLabel *label_107;
    QLabel *label_108;
    QLabel *label_109;
    QLabel *label_110;
    QLabel *label_111;
    QLabel *label_112;
    QLabel *label_113;
    QLabel *label_114;
    QCheckBox *ckCrossBDOBUSJ19J110;
    QCheckBox *ckBDOBUSJ19J110;
    QCheckBox *ckCrossBDOBUSJ111J25;
    QCheckBox *ckBDOBUSJ111J25;
    QCheckBox *ckCrossBDOBUSJ113J27;
    QCheckBox *ckBDOBUSJ113J27;
    QCheckBox *ckCrossBDOBUSJ115J29;
    QCheckBox *ckBDOBUSJ115J29;
    QCheckBox *ckCrossEmergencyStop;
    QCheckBox *ckEmergencyStop;
    QPushButton *pbHarness_2;
    QLabel *lblBDOBUSJ17J21;
    QLabel *lblBDOBUSJ19J23;
    QLabel *lblBDOBUSJ110J24;
    QLabel *lblBDOBUSJ112J26;
    QLabel *lblBDOBUSJ114J28;
    QLabel *lblShellLoading;
    QLabel *lblBDOBUSJ18J22;
    QLabel *lblBDOBUSJ19J110;
    QLabel *lblBDOBUSJ111J25;
    QLabel *lblBDOBUSJ113J27;
    QLabel *lblBDOBUSJ115J29;
    QLabel *lblEmergencyStop;
    QGroupBox *groupBox;
    QLabel *lblHarnessLED;
    QPushButton *pbHarness;
    QCheckBox *ckHarnessContinutyError;
    QLabel *label_103;
    QLabel *label_104;
    QLabel *label_105;
    QLabel *lblHarness;
    QLabel *lblOPRMODE_2;

    void setupUi(QWidget *bdobus)
    {
        if (bdobus->objectName().isEmpty())
            bdobus->setObjectName(QStringLiteral("bdobus"));
        bdobus->resize(1900, 902);
        widget_14 = new QWidget(bdobus);
        widget_14->setObjectName(QStringLiteral("widget_14"));
        widget_14->setGeometry(QRect(145, 250, 1621, 631));
        widget_14->setStyleSheet(QLatin1String("background:color rgb(150,160,186,40%);\n"
"border-radius:10px;"));
        lblBDOBUSJ17J21LED = new QLabel(widget_14);
        lblBDOBUSJ17J21LED->setObjectName(QStringLiteral("lblBDOBUSJ17J21LED"));
        lblBDOBUSJ17J21LED->setGeometry(QRect(333, 160, 30, 30));
        lblBDOBUSJ17J21LED->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        lblBDOBUSJ19J23LED = new QLabel(widget_14);
        lblBDOBUSJ19J23LED->setObjectName(QStringLiteral("lblBDOBUSJ19J23LED"));
        lblBDOBUSJ19J23LED->setGeometry(QRect(333, 236, 30, 30));
        lblBDOBUSJ19J23LED->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        lblBDOBUSJ110J24LED = new QLabel(widget_14);
        lblBDOBUSJ110J24LED->setObjectName(QStringLiteral("lblBDOBUSJ110J24LED"));
        lblBDOBUSJ110J24LED->setGeometry(QRect(333, 317, 30, 30));
        lblBDOBUSJ110J24LED->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        lblBDOBUSJ112J26LED = new QLabel(widget_14);
        lblBDOBUSJ112J26LED->setObjectName(QStringLiteral("lblBDOBUSJ112J26LED"));
        lblBDOBUSJ112J26LED->setGeometry(QRect(333, 396, 30, 30));
        lblBDOBUSJ112J26LED->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        lblBDOBUSJ114J28LED = new QLabel(widget_14);
        lblBDOBUSJ114J28LED->setObjectName(QStringLiteral("lblBDOBUSJ114J28LED"));
        lblBDOBUSJ114J28LED->setGeometry(QRect(333, 475, 30, 30));
        lblBDOBUSJ114J28LED->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        lblBDOBUSJ18J22LED = new QLabel(widget_14);
        lblBDOBUSJ18J22LED->setObjectName(QStringLiteral("lblBDOBUSJ18J22LED"));
        lblBDOBUSJ18J22LED->setGeometry(QRect(1189, 160, 30, 30));
        lblBDOBUSJ18J22LED->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        lblBDOBUSJ19J110LED = new QLabel(widget_14);
        lblBDOBUSJ19J110LED->setObjectName(QStringLiteral("lblBDOBUSJ19J110LED"));
        lblBDOBUSJ19J110LED->setGeometry(QRect(1189, 235, 30, 30));
        lblBDOBUSJ19J110LED->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        lblBDOBUSJ111J25LED = new QLabel(widget_14);
        lblBDOBUSJ111J25LED->setObjectName(QStringLiteral("lblBDOBUSJ111J25LED"));
        lblBDOBUSJ111J25LED->setGeometry(QRect(1189, 317, 30, 30));
        lblBDOBUSJ111J25LED->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        lblBDOBUSJ113J27LED = new QLabel(widget_14);
        lblBDOBUSJ113J27LED->setObjectName(QStringLiteral("lblBDOBUSJ113J27LED"));
        lblBDOBUSJ113J27LED->setGeometry(QRect(1189, 396, 30, 30));
        lblBDOBUSJ113J27LED->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        lblBDOBUSJ115J29LED = new QLabel(widget_14);
        lblBDOBUSJ115J29LED->setObjectName(QStringLiteral("lblBDOBUSJ115J29LED"));
        lblBDOBUSJ115J29LED->setGeometry(QRect(1189, 475, 30, 30));
        lblBDOBUSJ115J29LED->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        lblShellLoadingLED = new QLabel(widget_14);
        lblShellLoadingLED->setObjectName(QStringLiteral("lblShellLoadingLED"));
        lblShellLoadingLED->setGeometry(QRect(333, 556, 30, 30));
        lblShellLoadingLED->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        lblEmergencyStopLED = new QLabel(widget_14);
        lblEmergencyStopLED->setObjectName(QStringLiteral("lblEmergencyStopLED"));
        lblEmergencyStopLED->setGeometry(QRect(1189, 556, 30, 30));
        lblEmergencyStopLED->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        ckBDOBUSJ17J21 = new QCheckBox(widget_14);
        ckBDOBUSJ17J21->setObjectName(QStringLiteral("ckBDOBUSJ17J21"));
        ckBDOBUSJ17J21->setGeometry(QRect(456, 160, 31, 31));
        QFont font;
        ckBDOBUSJ17J21->setFont(font);
        ckBDOBUSJ17J21->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        ckBDOBUSJ19J23 = new QCheckBox(widget_14);
        ckBDOBUSJ19J23->setObjectName(QStringLiteral("ckBDOBUSJ19J23"));
        ckBDOBUSJ19J23->setGeometry(QRect(456, 236, 31, 31));
        ckBDOBUSJ19J23->setFont(font);
        ckBDOBUSJ19J23->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        ckBDOBUSJ110J24 = new QCheckBox(widget_14);
        ckBDOBUSJ110J24->setObjectName(QStringLiteral("ckBDOBUSJ110J24"));
        ckBDOBUSJ110J24->setGeometry(QRect(456, 317, 31, 31));
        ckBDOBUSJ110J24->setFont(font);
        ckBDOBUSJ110J24->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        ckBDOBUSJ112J26 = new QCheckBox(widget_14);
        ckBDOBUSJ112J26->setObjectName(QStringLiteral("ckBDOBUSJ112J26"));
        ckBDOBUSJ112J26->setGeometry(QRect(456, 396, 31, 31));
        ckBDOBUSJ112J26->setFont(font);
        ckBDOBUSJ112J26->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        ckBDOBUSJ114J28 = new QCheckBox(widget_14);
        ckBDOBUSJ114J28->setObjectName(QStringLiteral("ckBDOBUSJ114J28"));
        ckBDOBUSJ114J28->setGeometry(QRect(456, 474, 31, 31));
        ckBDOBUSJ114J28->setFont(font);
        ckBDOBUSJ114J28->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        ckShellLoading = new QCheckBox(widget_14);
        ckShellLoading->setObjectName(QStringLiteral("ckShellLoading"));
        ckShellLoading->setGeometry(QRect(456, 556, 31, 31));
        ckShellLoading->setFont(font);
        ckShellLoading->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        ckCrossBDOBUSJ17J21 = new QCheckBox(widget_14);
        ckCrossBDOBUSJ17J21->setObjectName(QStringLiteral("ckCrossBDOBUSJ17J21"));
        ckCrossBDOBUSJ17J21->setGeometry(QRect(635, 160, 31, 31));
        ckCrossBDOBUSJ17J21->setFont(font);
        ckCrossBDOBUSJ17J21->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        ckCrossBDOBUSJ19J23 = new QCheckBox(widget_14);
        ckCrossBDOBUSJ19J23->setObjectName(QStringLiteral("ckCrossBDOBUSJ19J23"));
        ckCrossBDOBUSJ19J23->setGeometry(QRect(635, 236, 31, 31));
        ckCrossBDOBUSJ19J23->setFont(font);
        ckCrossBDOBUSJ19J23->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        ckCrossBDOBUSJ110J24 = new QCheckBox(widget_14);
        ckCrossBDOBUSJ110J24->setObjectName(QStringLiteral("ckCrossBDOBUSJ110J24"));
        ckCrossBDOBUSJ110J24->setGeometry(QRect(635, 317, 31, 31));
        ckCrossBDOBUSJ110J24->setFont(font);
        ckCrossBDOBUSJ110J24->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        ckCrossBDOBUSJ112J26 = new QCheckBox(widget_14);
        ckCrossBDOBUSJ112J26->setObjectName(QStringLiteral("ckCrossBDOBUSJ112J26"));
        ckCrossBDOBUSJ112J26->setGeometry(QRect(635, 396, 31, 31));
        ckCrossBDOBUSJ112J26->setFont(font);
        ckCrossBDOBUSJ112J26->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        ckCrossBDOBUSJ114J28 = new QCheckBox(widget_14);
        ckCrossBDOBUSJ114J28->setObjectName(QStringLiteral("ckCrossBDOBUSJ114J28"));
        ckCrossBDOBUSJ114J28->setGeometry(QRect(635, 474, 31, 31));
        ckCrossBDOBUSJ114J28->setFont(font);
        ckCrossBDOBUSJ114J28->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        ckCrossShellLoading = new QCheckBox(widget_14);
        ckCrossShellLoading->setObjectName(QStringLiteral("ckCrossShellLoading"));
        ckCrossShellLoading->setGeometry(QRect(635, 556, 31, 31));
        ckCrossShellLoading->setFont(font);
        ckCrossShellLoading->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        ckCrossBDOBUSJ18J22 = new QCheckBox(widget_14);
        ckCrossBDOBUSJ18J22->setObjectName(QStringLiteral("ckCrossBDOBUSJ18J22"));
        ckCrossBDOBUSJ18J22->setGeometry(QRect(1496, 160, 31, 31));
        ckCrossBDOBUSJ18J22->setFont(font);
        ckCrossBDOBUSJ18J22->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        ckBDOBUSJ18J22 = new QCheckBox(widget_14);
        ckBDOBUSJ18J22->setObjectName(QStringLiteral("ckBDOBUSJ18J22"));
        ckBDOBUSJ18J22->setGeometry(QRect(1319, 160, 31, 31));
        ckBDOBUSJ18J22->setFont(font);
        ckBDOBUSJ18J22->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        label_107 = new QLabel(widget_14);
        label_107->setObjectName(QStringLiteral("label_107"));
        label_107->setGeometry(QRect(122, 73, 61, 38));
        QFont font1;
        font1.setFamily(QStringLiteral("Roboto"));
        font1.setPointSize(16);
        font1.setBold(true);
        font1.setWeight(75);
        label_107->setFont(font1);
        label_107->setStyleSheet(QLatin1String("background:color rgb(150,160,186,1%);\n"
"color:rgb(53,74, 131);"));
        label_108 = new QLabel(widget_14);
        label_108->setObjectName(QStringLiteral("label_108"));
        label_108->setGeometry(QRect(309, 73, 81, 38));
        label_108->setFont(font1);
        label_108->setStyleSheet(QLatin1String("background:color rgb(150,160,186,1%);\n"
"color:rgb(53,74, 131);"));
        label_108->setAlignment(Qt::AlignCenter);
        label_109 = new QLabel(widget_14);
        label_109->setObjectName(QStringLiteral("label_109"));
        label_109->setGeometry(QRect(415, 70, 121, 61));
        label_109->setFont(font1);
        label_109->setStyleSheet(QLatin1String("background:color rgb(150,160,186,0%);\n"
"color:rgb(53,74, 131);"));
        label_109->setAlignment(Qt::AlignCenter);
        label_110 = new QLabel(widget_14);
        label_110->setObjectName(QStringLiteral("label_110"));
        label_110->setGeometry(QRect(550, 64, 201, 71));
        label_110->setFont(font1);
        label_110->setStyleSheet(QLatin1String("background:color rgb(150,160,186,1%);\n"
"color:rgb(53,74, 131);"));
        label_110->setAlignment(Qt::AlignCenter);
        label_111 = new QLabel(widget_14);
        label_111->setObjectName(QStringLiteral("label_111"));
        label_111->setGeometry(QRect(962, 73, 61, 38));
        label_111->setFont(font1);
        label_111->setStyleSheet(QLatin1String("background:color rgb(150,160,186,1%);\n"
"color:rgb(53,74, 131);"));
        label_112 = new QLabel(widget_14);
        label_112->setObjectName(QStringLiteral("label_112"));
        label_112->setGeometry(QRect(1412, 67, 201, 71));
        label_112->setFont(font1);
        label_112->setStyleSheet(QLatin1String("background:color rgb(150,160,186,1%);\n"
"color:rgb(53,74, 131);"));
        label_112->setAlignment(Qt::AlignCenter);
        label_113 = new QLabel(widget_14);
        label_113->setObjectName(QStringLiteral("label_113"));
        label_113->setGeometry(QRect(1164, 73, 81, 38));
        label_113->setFont(font1);
        label_113->setStyleSheet(QLatin1String("background:color rgb(150,160,186,1%);\n"
"color:rgb(53,74, 131);"));
        label_113->setAlignment(Qt::AlignCenter);
        label_114 = new QLabel(widget_14);
        label_114->setObjectName(QStringLiteral("label_114"));
        label_114->setGeometry(QRect(1280, 73, 121, 61));
        label_114->setFont(font1);
        label_114->setStyleSheet(QLatin1String("background:color rgb(150,160,186,0%);\n"
"color:rgb(53,74, 131);"));
        label_114->setAlignment(Qt::AlignCenter);
        ckCrossBDOBUSJ19J110 = new QCheckBox(widget_14);
        ckCrossBDOBUSJ19J110->setObjectName(QStringLiteral("ckCrossBDOBUSJ19J110"));
        ckCrossBDOBUSJ19J110->setGeometry(QRect(1496, 235, 31, 31));
        ckCrossBDOBUSJ19J110->setFont(font);
        ckCrossBDOBUSJ19J110->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        ckBDOBUSJ19J110 = new QCheckBox(widget_14);
        ckBDOBUSJ19J110->setObjectName(QStringLiteral("ckBDOBUSJ19J110"));
        ckBDOBUSJ19J110->setGeometry(QRect(1319, 235, 31, 31));
        ckBDOBUSJ19J110->setFont(font);
        ckBDOBUSJ19J110->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        ckCrossBDOBUSJ111J25 = new QCheckBox(widget_14);
        ckCrossBDOBUSJ111J25->setObjectName(QStringLiteral("ckCrossBDOBUSJ111J25"));
        ckCrossBDOBUSJ111J25->setGeometry(QRect(1496, 317, 31, 31));
        ckCrossBDOBUSJ111J25->setFont(font);
        ckCrossBDOBUSJ111J25->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        ckBDOBUSJ111J25 = new QCheckBox(widget_14);
        ckBDOBUSJ111J25->setObjectName(QStringLiteral("ckBDOBUSJ111J25"));
        ckBDOBUSJ111J25->setGeometry(QRect(1319, 317, 31, 31));
        ckBDOBUSJ111J25->setFont(font);
        ckBDOBUSJ111J25->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        ckCrossBDOBUSJ113J27 = new QCheckBox(widget_14);
        ckCrossBDOBUSJ113J27->setObjectName(QStringLiteral("ckCrossBDOBUSJ113J27"));
        ckCrossBDOBUSJ113J27->setGeometry(QRect(1496, 396, 31, 31));
        ckCrossBDOBUSJ113J27->setFont(font);
        ckCrossBDOBUSJ113J27->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        ckBDOBUSJ113J27 = new QCheckBox(widget_14);
        ckBDOBUSJ113J27->setObjectName(QStringLiteral("ckBDOBUSJ113J27"));
        ckBDOBUSJ113J27->setGeometry(QRect(1319, 396, 31, 31));
        ckBDOBUSJ113J27->setFont(font);
        ckBDOBUSJ113J27->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        ckCrossBDOBUSJ115J29 = new QCheckBox(widget_14);
        ckCrossBDOBUSJ115J29->setObjectName(QStringLiteral("ckCrossBDOBUSJ115J29"));
        ckCrossBDOBUSJ115J29->setGeometry(QRect(1496, 475, 31, 31));
        ckCrossBDOBUSJ115J29->setFont(font);
        ckCrossBDOBUSJ115J29->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        ckBDOBUSJ115J29 = new QCheckBox(widget_14);
        ckBDOBUSJ115J29->setObjectName(QStringLiteral("ckBDOBUSJ115J29"));
        ckBDOBUSJ115J29->setGeometry(QRect(1319, 475, 31, 31));
        ckBDOBUSJ115J29->setFont(font);
        ckBDOBUSJ115J29->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        ckCrossEmergencyStop = new QCheckBox(widget_14);
        ckCrossEmergencyStop->setObjectName(QStringLiteral("ckCrossEmergencyStop"));
        ckCrossEmergencyStop->setGeometry(QRect(1496, 556, 31, 31));
        ckCrossEmergencyStop->setFont(font);
        ckCrossEmergencyStop->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        ckEmergencyStop = new QCheckBox(widget_14);
        ckEmergencyStop->setObjectName(QStringLiteral("ckEmergencyStop"));
        ckEmergencyStop->setGeometry(QRect(1319, 556, 31, 31));
        ckEmergencyStop->setFont(font);
        ckEmergencyStop->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        pbHarness_2 = new QPushButton(widget_14);
        pbHarness_2->setObjectName(QStringLiteral("pbHarness_2"));
        pbHarness_2->setGeometry(QRect(0, 6, 321, 41));
        QFont font2;
        font2.setPointSize(14);
        pbHarness_2->setFont(font2);
        pbHarness_2->setStyleSheet(QLatin1String("background-color: rgb(53, 74, 131); \n"
"color: rgb(255, 255, 255);"));
        lblBDOBUSJ17J21 = new QLabel(widget_14);
        lblBDOBUSJ17J21->setObjectName(QStringLiteral("lblBDOBUSJ17J21"));
        lblBDOBUSJ17J21->setGeometry(QRect(20, 155, 260, 40));
        QFont font3;
        font3.setFamily(QStringLiteral("Roboto"));
        font3.setPointSize(13);
        font3.setBold(true);
        font3.setWeight(75);
        lblBDOBUSJ17J21->setFont(font3);
        lblBDOBUSJ17J21->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBDOBUSJ17J21->setAlignment(Qt::AlignCenter);
        lblBDOBUSJ19J23 = new QLabel(widget_14);
        lblBDOBUSJ19J23->setObjectName(QStringLiteral("lblBDOBUSJ19J23"));
        lblBDOBUSJ19J23->setGeometry(QRect(20, 232, 260, 40));
        lblBDOBUSJ19J23->setFont(font3);
        lblBDOBUSJ19J23->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBDOBUSJ19J23->setAlignment(Qt::AlignCenter);
        lblBDOBUSJ110J24 = new QLabel(widget_14);
        lblBDOBUSJ110J24->setObjectName(QStringLiteral("lblBDOBUSJ110J24"));
        lblBDOBUSJ110J24->setGeometry(QRect(20, 312, 260, 40));
        lblBDOBUSJ110J24->setFont(font3);
        lblBDOBUSJ110J24->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBDOBUSJ110J24->setAlignment(Qt::AlignCenter);
        lblBDOBUSJ112J26 = new QLabel(widget_14);
        lblBDOBUSJ112J26->setObjectName(QStringLiteral("lblBDOBUSJ112J26"));
        lblBDOBUSJ112J26->setGeometry(QRect(20, 391, 260, 40));
        lblBDOBUSJ112J26->setFont(font3);
        lblBDOBUSJ112J26->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBDOBUSJ112J26->setAlignment(Qt::AlignCenter);
        lblBDOBUSJ114J28 = new QLabel(widget_14);
        lblBDOBUSJ114J28->setObjectName(QStringLiteral("lblBDOBUSJ114J28"));
        lblBDOBUSJ114J28->setGeometry(QRect(20, 470, 260, 40));
        lblBDOBUSJ114J28->setFont(font3);
        lblBDOBUSJ114J28->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBDOBUSJ114J28->setAlignment(Qt::AlignCenter);
        lblShellLoading = new QLabel(widget_14);
        lblShellLoading->setObjectName(QStringLiteral("lblShellLoading"));
        lblShellLoading->setGeometry(QRect(20, 551, 260, 40));
        lblShellLoading->setFont(font3);
        lblShellLoading->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblShellLoading->setAlignment(Qt::AlignCenter);
        lblBDOBUSJ18J22 = new QLabel(widget_14);
        lblBDOBUSJ18J22->setObjectName(QStringLiteral("lblBDOBUSJ18J22"));
        lblBDOBUSJ18J22->setGeometry(QRect(860, 155, 260, 40));
        lblBDOBUSJ18J22->setFont(font3);
        lblBDOBUSJ18J22->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBDOBUSJ18J22->setAlignment(Qt::AlignCenter);
        lblBDOBUSJ19J110 = new QLabel(widget_14);
        lblBDOBUSJ19J110->setObjectName(QStringLiteral("lblBDOBUSJ19J110"));
        lblBDOBUSJ19J110->setGeometry(QRect(860, 232, 260, 40));
        lblBDOBUSJ19J110->setFont(font3);
        lblBDOBUSJ19J110->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBDOBUSJ19J110->setAlignment(Qt::AlignCenter);
        lblBDOBUSJ111J25 = new QLabel(widget_14);
        lblBDOBUSJ111J25->setObjectName(QStringLiteral("lblBDOBUSJ111J25"));
        lblBDOBUSJ111J25->setGeometry(QRect(860, 312, 260, 40));
        lblBDOBUSJ111J25->setFont(font3);
        lblBDOBUSJ111J25->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBDOBUSJ111J25->setAlignment(Qt::AlignCenter);
        lblBDOBUSJ113J27 = new QLabel(widget_14);
        lblBDOBUSJ113J27->setObjectName(QStringLiteral("lblBDOBUSJ113J27"));
        lblBDOBUSJ113J27->setGeometry(QRect(860, 391, 260, 40));
        lblBDOBUSJ113J27->setFont(font3);
        lblBDOBUSJ113J27->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBDOBUSJ113J27->setAlignment(Qt::AlignCenter);
        lblBDOBUSJ115J29 = new QLabel(widget_14);
        lblBDOBUSJ115J29->setObjectName(QStringLiteral("lblBDOBUSJ115J29"));
        lblBDOBUSJ115J29->setGeometry(QRect(860, 470, 260, 40));
        lblBDOBUSJ115J29->setFont(font3);
        lblBDOBUSJ115J29->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBDOBUSJ115J29->setAlignment(Qt::AlignCenter);
        lblEmergencyStop = new QLabel(widget_14);
        lblEmergencyStop->setObjectName(QStringLiteral("lblEmergencyStop"));
        lblEmergencyStop->setGeometry(QRect(860, 551, 260, 40));
        lblEmergencyStop->setFont(font3);
        lblEmergencyStop->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblEmergencyStop->setAlignment(Qt::AlignCenter);
        groupBox = new QGroupBox(bdobus);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(490, 83, 931, 149));
        groupBox->setStyleSheet(QLatin1String("background:color rgb(150,160,186,40%);\n"
"border-radius:10px;"));
        lblHarnessLED = new QLabel(groupBox);
        lblHarnessLED->setObjectName(QStringLiteral("lblHarnessLED"));
        lblHarnessLED->setGeometry(QRect(519, 94, 30, 30));
        lblHarnessLED->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        pbHarness = new QPushButton(groupBox);
        pbHarness->setObjectName(QStringLiteral("pbHarness"));
        pbHarness->setGeometry(QRect(0, 0, 441, 41));
        pbHarness->setFont(font2);
        pbHarness->setStyleSheet(QLatin1String("background-color: rgb(53, 74, 131); \n"
"color: rgb(255, 255, 255);"));
        ckHarnessContinutyError = new QCheckBox(groupBox);
        ckHarnessContinutyError->setObjectName(QStringLiteral("ckHarnessContinutyError"));
        ckHarnessContinutyError->setGeometry(QRect(672, 95, 31, 31));
        ckHarnessContinutyError->setFont(font);
        ckHarnessContinutyError->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        label_103 = new QLabel(groupBox);
        label_103->setObjectName(QStringLiteral("label_103"));
        label_103->setGeometry(QRect(310, 42, 61, 38));
        label_103->setFont(font1);
        label_103->setStyleSheet(QLatin1String("background:color rgb(150,160,186,1%);\n"
"color:rgb(53,74, 131);"));
        label_104 = new QLabel(groupBox);
        label_104->setObjectName(QStringLiteral("label_104"));
        label_104->setGeometry(QRect(494, 44, 81, 33));
        label_104->setFont(font1);
        label_104->setStyleSheet(QLatin1String("background:color rgb(150,160,186,1%);\n"
"color:rgb(53,74, 131);"));
        label_104->setAlignment(Qt::AlignCenter);
        label_105 = new QLabel(groupBox);
        label_105->setObjectName(QStringLiteral("label_105"));
        label_105->setGeometry(QRect(582, 44, 211, 41));
        label_105->setFont(font1);
        label_105->setStyleSheet(QLatin1String("background:color rgb(150,160,186,1%);\n"
"color:rgb(53,74, 131);"));
        lblHarness = new QLabel(groupBox);
        lblHarness->setObjectName(QStringLiteral("lblHarness"));
        lblHarness->setGeometry(QRect(196, 90, 260, 40));
        lblHarness->setFont(font3);
        lblHarness->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblHarness->setAlignment(Qt::AlignCenter);
        lblOPRMODE_2 = new QLabel(bdobus);
        lblOPRMODE_2->setObjectName(QStringLiteral("lblOPRMODE_2"));
        lblOPRMODE_2->setGeometry(QRect(810, 0, 291, 77));
        QFont font4;
        font4.setFamily(QStringLiteral("Roboto"));
        font4.setPointSize(25);
        font4.setBold(true);
        font4.setUnderline(true);
        font4.setWeight(75);
        lblOPRMODE_2->setFont(font4);
        lblOPRMODE_2->setStyleSheet(QLatin1String("\n"
"\n"
"\n"
"color:rgb(53,74, 131);\n"
""));
        lblOPRMODE_2->setAlignment(Qt::AlignCenter);

        retranslateUi(bdobus);

        QMetaObject::connectSlotsByName(bdobus);
    } // setupUi

    void retranslateUi(QWidget *bdobus)
    {
        bdobus->setWindowTitle(QApplication::translate("bdobus", "Form", Q_NULLPTR));
        lblBDOBUSJ17J21LED->setText(QString());
        lblBDOBUSJ19J23LED->setText(QString());
        lblBDOBUSJ110J24LED->setText(QString());
        lblBDOBUSJ112J26LED->setText(QString());
        lblBDOBUSJ114J28LED->setText(QString());
        lblBDOBUSJ18J22LED->setText(QString());
        lblBDOBUSJ19J110LED->setText(QString());
        lblBDOBUSJ111J25LED->setText(QString());
        lblBDOBUSJ113J27LED->setText(QString());
        lblBDOBUSJ115J29LED->setText(QString());
        lblShellLoadingLED->setText(QString());
        lblEmergencyStopLED->setText(QString());
        ckBDOBUSJ17J21->setText(QString());
        ckBDOBUSJ19J23->setText(QString());
        ckBDOBUSJ110J24->setText(QString());
        ckBDOBUSJ112J26->setText(QString());
        ckBDOBUSJ114J28->setText(QString());
        ckShellLoading->setText(QString());
        ckCrossBDOBUSJ17J21->setText(QString());
        ckCrossBDOBUSJ19J23->setText(QString());
        ckCrossBDOBUSJ110J24->setText(QString());
        ckCrossBDOBUSJ112J26->setText(QString());
        ckCrossBDOBUSJ114J28->setText(QString());
        ckCrossShellLoading->setText(QString());
        ckCrossBDOBUSJ18J22->setText(QString());
        ckBDOBUSJ18J22->setText(QString());
        label_107->setText(QApplication::translate("bdobus", "DI's", Q_NULLPTR));
        label_108->setText(QApplication::translate("bdobus", "DO's", Q_NULLPTR));
        label_109->setText(QApplication::translate("bdobus", "Continuty\n"
" Error", Q_NULLPTR));
        label_110->setText(QApplication::translate("bdobus", "Cross Continuty\n"
"Error", Q_NULLPTR));
        label_111->setText(QApplication::translate("bdobus", "DI's", Q_NULLPTR));
        label_112->setText(QApplication::translate("bdobus", "Cross Continuty\n"
"Error", Q_NULLPTR));
        label_113->setText(QApplication::translate("bdobus", "DO's", Q_NULLPTR));
        label_114->setText(QApplication::translate("bdobus", "Continuty\n"
" Error", Q_NULLPTR));
        ckCrossBDOBUSJ19J110->setText(QString());
        ckBDOBUSJ19J110->setText(QString());
        ckCrossBDOBUSJ111J25->setText(QString());
        ckBDOBUSJ111J25->setText(QString());
        ckCrossBDOBUSJ113J27->setText(QString());
        ckBDOBUSJ113J27->setText(QString());
        ckCrossBDOBUSJ115J29->setText(QString());
        ckBDOBUSJ115J29->setText(QString());
        ckCrossEmergencyStop->setText(QString());
        ckEmergencyStop->setText(QString());
        pbHarness_2->setText(QApplication::translate("bdobus", "Test", Q_NULLPTR));
        lblBDOBUSJ17J21->setText(QApplication::translate("bdobus", "J1-7 to J2-1", Q_NULLPTR));
        lblBDOBUSJ19J23->setText(QApplication::translate("bdobus", "J1-9 to J2-3", Q_NULLPTR));
        lblBDOBUSJ110J24->setText(QApplication::translate("bdobus", "J1-10 to J2-4", Q_NULLPTR));
        lblBDOBUSJ112J26->setText(QApplication::translate("bdobus", "J1-12 to J2-6", Q_NULLPTR));
        lblBDOBUSJ114J28->setText(QApplication::translate("bdobus", "J1-14 to J2-8", Q_NULLPTR));
        lblShellLoading->setText(QApplication::translate("bdobus", "Shell loading", Q_NULLPTR));
        lblBDOBUSJ18J22->setText(QApplication::translate("bdobus", "J1-8 to J2-2", Q_NULLPTR));
        lblBDOBUSJ19J110->setText(QApplication::translate("bdobus", "J1-9 to J1-10", Q_NULLPTR));
        lblBDOBUSJ111J25->setText(QApplication::translate("bdobus", "J1-11 to J2-5", Q_NULLPTR));
        lblBDOBUSJ113J27->setText(QApplication::translate("bdobus", "J1-13 to J2-7", Q_NULLPTR));
        lblBDOBUSJ115J29->setText(QApplication::translate("bdobus", "J1-15 to J2-9", Q_NULLPTR));
        lblEmergencyStop->setText(QApplication::translate("bdobus", "Emergency stop", Q_NULLPTR));
        groupBox->setTitle(QString());
        lblHarnessLED->setText(QString());
        pbHarness->setText(QApplication::translate("bdobus", "BDOBUS Harness Check connection", Q_NULLPTR));
        ckHarnessContinutyError->setText(QString());
        label_103->setText(QApplication::translate("bdobus", "DI's", Q_NULLPTR));
        label_104->setText(QApplication::translate("bdobus", "DO's", Q_NULLPTR));
        label_105->setText(QApplication::translate("bdobus", "Continuty Error", Q_NULLPTR));
        lblHarness->setText(QApplication::translate("bdobus", "Harness", Q_NULLPTR));
        lblOPRMODE_2->setText(QApplication::translate("bdobus", "BDOBUS", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class bdobus: public Ui_bdobus {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_BDOBUS_H
