/********************************************************************************
** Form generated from reading UI file 'bfcmdf.ui'
**
** Created by: Qt User Interface Compiler version 5.9.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_BFCMDF_H
#define UI_BFCMDF_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_bfcmdf
{
public:
    QGroupBox *groupBox;
    QLabel *lblHarnessLED;
    QLabel *lblHarness;
    QPushButton *pbHarness;
    QLabel *label_103;
    QLabel *label_104;
    QLabel *label_105;
    QCheckBox *ckHarnessContinutyError;
    QGroupBox *groupBox_2;
    QLabel *lblJ1_11TOj1_12LED;
    QLabel *lblJ1_11TOj1_12;
    QPushButton *pbHarness_2;
    QLabel *label_107;
    QCheckBox *ckContinutyJ1_11toJ1_12;
    QLabel *label_106;
    QLabel *lblOPRMODE_2;

    void setupUi(QWidget *bfcmdf)
    {
        if (bfcmdf->objectName().isEmpty())
            bfcmdf->setObjectName(QStringLiteral("bfcmdf"));
        bfcmdf->resize(1900, 900);
        groupBox = new QGroupBox(bfcmdf);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(462, 130, 761, 155));
        groupBox->setStyleSheet(QLatin1String("background:color rgb(150,160,186,40%);\n"
"border-radius:10px;"));
        lblHarnessLED = new QLabel(groupBox);
        lblHarnessLED->setObjectName(QStringLiteral("lblHarnessLED"));
        lblHarnessLED->setGeometry(QRect(360, 94, 30, 30));
        lblHarnessLED->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        lblHarness = new QLabel(groupBox);
        lblHarness->setObjectName(QStringLiteral("lblHarness"));
        lblHarness->setGeometry(QRect(17, 88, 218, 40));
        QFont font;
        font.setFamily(QStringLiteral("Roboto"));
        font.setPointSize(13);
        font.setBold(true);
        font.setWeight(75);
        lblHarness->setFont(font);
        lblHarness->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblHarness->setAlignment(Qt::AlignCenter);
        pbHarness = new QPushButton(groupBox);
        pbHarness->setObjectName(QStringLiteral("pbHarness"));
        pbHarness->setGeometry(QRect(0, 0, 441, 41));
        QFont font1;
        font1.setPointSize(14);
        pbHarness->setFont(font1);
        pbHarness->setStyleSheet(QLatin1String("background-color: rgb(53, 74, 131); \n"
"color: rgb(255, 255, 255);"));
        label_103 = new QLabel(groupBox);
        label_103->setObjectName(QStringLiteral("label_103"));
        label_103->setGeometry(QRect(121, 52, 61, 38));
        QFont font2;
        font2.setFamily(QStringLiteral("Roboto"));
        font2.setPointSize(16);
        font2.setBold(true);
        font2.setWeight(75);
        label_103->setFont(font2);
        label_103->setStyleSheet(QLatin1String("background:color rgb(150,160,186,1%);\n"
"color:rgb(53,74, 131);"));
        label_104 = new QLabel(groupBox);
        label_104->setObjectName(QStringLiteral("label_104"));
        label_104->setGeometry(QRect(335, 54, 81, 33));
        label_104->setFont(font2);
        label_104->setStyleSheet(QLatin1String("background:color rgb(150,160,186,1%);\n"
"color:rgb(53,74, 131);"));
        label_104->setAlignment(Qt::AlignCenter);
        label_105 = new QLabel(groupBox);
        label_105->setObjectName(QStringLiteral("label_105"));
        label_105->setGeometry(QRect(460, 51, 191, 41));
        label_105->setFont(font2);
        label_105->setStyleSheet(QLatin1String("background:color rgb(150,160,186,1%);\n"
"color:rgb(53,74, 131);"));
        ckHarnessContinutyError = new QCheckBox(groupBox);
        ckHarnessContinutyError->setObjectName(QStringLiteral("ckHarnessContinutyError"));
        ckHarnessContinutyError->setGeometry(QRect(540, 95, 31, 31));
        QFont font3;
        ckHarnessContinutyError->setFont(font3);
        ckHarnessContinutyError->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        groupBox_2 = new QGroupBox(bfcmdf);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        groupBox_2->setGeometry(QRect(460, 300, 761, 155));
        groupBox_2->setStyleSheet(QLatin1String("background:color rgb(150,160,186,40%);\n"
"border-radius:10px;"));
        lblJ1_11TOj1_12LED = new QLabel(groupBox_2);
        lblJ1_11TOj1_12LED->setObjectName(QStringLiteral("lblJ1_11TOj1_12LED"));
        lblJ1_11TOj1_12LED->setGeometry(QRect(360, 94, 30, 30));
        lblJ1_11TOj1_12LED->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        lblJ1_11TOj1_12 = new QLabel(groupBox_2);
        lblJ1_11TOj1_12->setObjectName(QStringLiteral("lblJ1_11TOj1_12"));
        lblJ1_11TOj1_12->setGeometry(QRect(110, 89, 218, 40));
        lblJ1_11TOj1_12->setFont(font);
        lblJ1_11TOj1_12->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"/*border: 4px solid rgb(53,74, 131);*/\n"
"color:rgb(53,74, 131);\n"
"/*border-radius:5px;*/\n"
"\n"
"\n"
"\n"
""));
        lblJ1_11TOj1_12->setAlignment(Qt::AlignCenter);
        pbHarness_2 = new QPushButton(groupBox_2);
        pbHarness_2->setObjectName(QStringLiteral("pbHarness_2"));
        pbHarness_2->setGeometry(QRect(0, 0, 441, 41));
        pbHarness_2->setFont(font1);
        pbHarness_2->setStyleSheet(QLatin1String("background-color: rgb(53, 74, 131); \n"
"color: rgb(255, 255, 255);"));
        label_107 = new QLabel(groupBox_2);
        label_107->setObjectName(QStringLiteral("label_107"));
        label_107->setGeometry(QRect(335, 54, 81, 33));
        label_107->setFont(font2);
        label_107->setStyleSheet(QLatin1String("background:color rgb(150,160,186,1%);\n"
"color:rgb(53,74, 131);"));
        label_107->setAlignment(Qt::AlignCenter);
        ckContinutyJ1_11toJ1_12 = new QCheckBox(groupBox_2);
        ckContinutyJ1_11toJ1_12->setObjectName(QStringLiteral("ckContinutyJ1_11toJ1_12"));
        ckContinutyJ1_11toJ1_12->setGeometry(QRect(520, 100, 31, 31));
        ckContinutyJ1_11toJ1_12->setFont(font3);
        ckContinutyJ1_11toJ1_12->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        label_106 = new QLabel(groupBox_2);
        label_106->setObjectName(QStringLiteral("label_106"));
        label_106->setGeometry(QRect(440, 56, 191, 41));
        label_106->setFont(font2);
        label_106->setStyleSheet(QLatin1String("background:color rgb(150,160,186,1%);\n"
"color:rgb(53,74, 131);"));
        lblOPRMODE_2 = new QLabel(bfcmdf);
        lblOPRMODE_2->setObjectName(QStringLiteral("lblOPRMODE_2"));
        lblOPRMODE_2->setGeometry(QRect(700, 60, 291, 55));
        QFont font4;
        font4.setFamily(QStringLiteral("Roboto"));
        font4.setPointSize(25);
        font4.setBold(true);
        font4.setUnderline(true);
        font4.setWeight(75);
        lblOPRMODE_2->setFont(font4);
        lblOPRMODE_2->setStyleSheet(QLatin1String("\n"
"background:rgb(234, 236, 247);\n"
"\n"
"\n"
"color:rgb(53,74, 131);\n"
""));
        lblOPRMODE_2->setAlignment(Qt::AlignCenter);

        retranslateUi(bfcmdf);

        QMetaObject::connectSlotsByName(bfcmdf);
    } // setupUi

    void retranslateUi(QWidget *bfcmdf)
    {
        bfcmdf->setWindowTitle(QApplication::translate("bfcmdf", "Form", Q_NULLPTR));
        groupBox->setTitle(QString());
        lblHarnessLED->setText(QString());
        lblHarness->setText(QApplication::translate("bfcmdf", "Harness", Q_NULLPTR));
        pbHarness->setText(QApplication::translate("bfcmdf", "BBAT harness check connection", Q_NULLPTR));
        label_103->setText(QApplication::translate("bfcmdf", "DI's", Q_NULLPTR));
        label_104->setText(QApplication::translate("bfcmdf", "DO's", Q_NULLPTR));
        label_105->setText(QApplication::translate("bfcmdf", "Continuty Error", Q_NULLPTR));
        ckHarnessContinutyError->setText(QString());
        groupBox_2->setTitle(QString());
        lblJ1_11TOj1_12LED->setText(QString());
        lblJ1_11TOj1_12->setText(QApplication::translate("bfcmdf", "J1-11 to J1-12", Q_NULLPTR));
        pbHarness_2->setText(QApplication::translate("bfcmdf", "Continuty Check", Q_NULLPTR));
        label_107->setText(QApplication::translate("bfcmdf", "DO's", Q_NULLPTR));
        ckContinutyJ1_11toJ1_12->setText(QString());
        label_106->setText(QApplication::translate("bfcmdf", "Continuty Error", Q_NULLPTR));
        lblOPRMODE_2->setText(QApplication::translate("bfcmdf", "BFCMDF", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class bfcmdf: public Ui_bfcmdf {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_BFCMDF_H
