/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QLabel *lblHederName;
    QLabel *lblUTMHTMStatus;
    QLabel *lblDateTime;
    QLabel *label_4;
    QFrame *frmMain;
    QFrame *frame;
    QPushButton *pbBDOBUS;
    QPushButton *pbBfcmdf;
    QPushButton *pushButton_4;
    QPushButton *pushButton_6;
    QPushButton *pushButton_7;
    QPushButton *pbRfu;
    QPushButton *pbBBAT;
    QPushButton *btnShutDown;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1912, 1080);
        MainWindow->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        lblHederName = new QLabel(centralWidget);
        lblHederName->setObjectName(QStringLiteral("lblHederName"));
        lblHederName->setGeometry(QRect(0, 0, 1900, 77));
        QFont font;
        font.setFamily(QStringLiteral("Roboto"));
        font.setPointSize(20);
        font.setBold(true);
        font.setWeight(75);
        lblHederName->setFont(font);
        lblHederName->setStyleSheet(QStringLiteral("background-color: rgb(53, 74, 131); "));
        lblHederName->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        lblUTMHTMStatus = new QLabel(centralWidget);
        lblUTMHTMStatus->setObjectName(QStringLiteral("lblUTMHTMStatus"));
        lblUTMHTMStatus->setGeometry(QRect(1430, 10, 230, 52));
        QFont font1;
        font1.setPointSize(12);
        font1.setBold(true);
        font1.setWeight(75);
        lblUTMHTMStatus->setFont(font1);
        lblUTMHTMStatus->setStyleSheet(QLatin1String("background-color: rgb(73, 202, 66); \n"
"color:white;\n"
"border-bottom-right-radius:10px;\n"
"border-top-left-radius:10px;"));
        lblUTMHTMStatus->setAlignment(Qt::AlignCenter);
        lblDateTime = new QLabel(centralWidget);
        lblDateTime->setObjectName(QStringLiteral("lblDateTime"));
        lblDateTime->setGeometry(QRect(1668, 10, 230, 52));
        QFont font2;
        font2.setPointSize(10);
        font2.setBold(true);
        font2.setWeight(75);
        lblDateTime->setFont(font2);
        lblDateTime->setStyleSheet(QLatin1String("background:color rgb(150,160,186,60%);\n"
"color:white;\n"
"border-bottom-right-radius:10px;\n"
"border-top-left-radius:10px;"));
        lblDateTime->setAlignment(Qt::AlignCenter);
        label_4 = new QLabel(centralWidget);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(724, 22, 451, 31));
        QFont font3;
        font3.setFamily(QStringLiteral("Roboto"));
        font3.setPointSize(20);
        label_4->setFont(font3);
        label_4->setStyleSheet(QLatin1String("background-color: rgb(53, 74, 131); \n"
"color: rgb(255, 255, 255);"));
        frmMain = new QFrame(centralWidget);
        frmMain->setObjectName(QStringLiteral("frmMain"));
        frmMain->setGeometry(QRect(6, 90, 1900, 900));
        frmMain->setStyleSheet(QStringLiteral(""));
        frmMain->setFrameShape(QFrame::StyledPanel);
        frmMain->setFrameShadow(QFrame::Raised);
        frame = new QFrame(centralWidget);
        frame->setObjectName(QStringLiteral("frame"));
        frame->setGeometry(QRect(6, 998, 1900, 82));
        frame->setStyleSheet(QLatin1String("background:color rgb(150,160,186,40%);\n"
"border-radius:10px;"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        pbBDOBUS = new QPushButton(frame);
        pbBDOBUS->setObjectName(QStringLiteral("pbBDOBUS"));
        pbBDOBUS->setGeometry(QRect(354, 15, 255, 55));
        QFont font4;
        font4.setFamily(QStringLiteral("Roboto"));
        font4.setPointSize(13);
        pbBDOBUS->setFont(font4);
        pbBDOBUS->setStyleSheet(QLatin1String("background-color: rgb(53, 74, 131); \n"
"color: rgb(255, 255, 255);\n"
"border-bottom-right-radius:00px;\n"
"border-top-right-radius:00px;\n"
"\n"
"border-bottom-left-radius:0px;\n"
"border-top-left-radius:00px;"));
        pbBfcmdf = new QPushButton(frame);
        pbBfcmdf->setObjectName(QStringLiteral("pbBfcmdf"));
        pbBfcmdf->setGeometry(QRect(609, 15, 255, 55));
        pbBfcmdf->setFont(font4);
        pbBfcmdf->setStyleSheet(QLatin1String("background-color: rgb(53, 74, 131); \n"
"color: rgb(255, 255, 255);\n"
"border-bottom-right-radius:00px;\n"
"border-top-right-radius:00px;\n"
"\n"
"border-bottom-left-radius:0px;\n"
"border-top-left-radius:00px;"));
        pushButton_4 = new QPushButton(frame);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(864, 15, 255, 55));
        pushButton_4->setFont(font4);
        pushButton_4->setStyleSheet(QLatin1String("background-color: rgb(53, 74, 131); \n"
"color: rgb(255, 255, 255);\n"
"border-bottom-right-radius:00px;\n"
"border-top-right-radius:00px;\n"
"\n"
"border-bottom-left-radius:0px;\n"
"border-top-left-radius:00px;"));
        pushButton_6 = new QPushButton(frame);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setGeometry(QRect(1119, 15, 255, 55));
        pushButton_6->setFont(font4);
        pushButton_6->setStyleSheet(QLatin1String("background-color: rgb(53, 74, 131); \n"
"color: rgb(255, 255, 255);\n"
"border-bottom-right-radius:00px;\n"
"border-top-right-radius:00px;\n"
"\n"
"border-bottom-left-radius:0px;\n"
"border-top-left-radius:00px;"));
        pushButton_7 = new QPushButton(frame);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        pushButton_7->setGeometry(QRect(1374, 15, 255, 55));
        pushButton_7->setFont(font4);
        pushButton_7->setStyleSheet(QLatin1String("background-color: rgb(53, 74, 131); \n"
"color: rgb(255, 255, 255);\n"
"border-bottom-right-radius:00px;\n"
"border-top-right-radius:00px;\n"
"\n"
"border-bottom-left-radius:0px;\n"
"border-top-left-radius:00px;"));
        pbRfu = new QPushButton(frame);
        pbRfu->setObjectName(QStringLiteral("pbRfu"));
        pbRfu->setGeometry(QRect(1629, 15, 255, 55));
        pbRfu->setFont(font4);
        pbRfu->setStyleSheet(QLatin1String("background-color: rgb(53, 74, 131); \n"
"color: rgb(255, 255, 255);\n"
"border-bottom-right-radius:10px;\n"
"border-top-right-radius:10px;\n"
"\n"
"border-bottom-left-radius:0px;\n"
"border-top-left-radius:00px;"));
        pbBBAT = new QPushButton(frame);
        pbBBAT->setObjectName(QStringLiteral("pbBBAT"));
        pbBBAT->setGeometry(QRect(99, 15, 255, 55));
        pbBBAT->setFont(font4);
        pbBBAT->setStyleSheet(QLatin1String("background-color: rgb(53, 74, 131); \n"
"color: rgb(255, 255, 255);\n"
"border-bottom-right-radius:00px;\n"
"border-top-right-radius:00px;\n"
"\n"
"border-bottom-left-radius:10px;\n"
"border-top-left-radius:10px;"));
        btnShutDown = new QPushButton(frame);
        btnShutDown->setObjectName(QStringLiteral("btnShutDown"));
        btnShutDown->setGeometry(QRect(12, 1, 80, 80));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Maximum);
        sizePolicy.setHorizontalStretch(26);
        sizePolicy.setVerticalStretch(18);
        sizePolicy.setHeightForWidth(btnShutDown->sizePolicy().hasHeightForWidth());
        btnShutDown->setSizePolicy(sizePolicy);
        QFont font5;
        font5.setPointSize(12);
        btnShutDown->setFont(font5);
        btnShutDown->setStyleSheet(QLatin1String("background-color: rgb(234, 236, 247); \n"
"\n"
"color:white;\n"
"border-radius:50px;"));
        btnShutDown->setIconSize(QSize(80, 80));
        MainWindow->setCentralWidget(centralWidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        lblHederName->setText(QString());
        lblUTMHTMStatus->setText(QApplication::translate("MainWindow", "UTM Connected", Q_NULLPTR));
        lblDateTime->setText(QApplication::translate("MainWindow", "04 -6 - 2024   18:55 ", Q_NULLPTR));
        label_4->setText(QApplication::translate("MainWindow", "EETIS_TESTJIG_SIMULATOR", Q_NULLPTR));
        pbBDOBUS->setText(QApplication::translate("MainWindow", "BDOBUS", Q_NULLPTR));
        pbBfcmdf->setText(QApplication::translate("MainWindow", "BFCMDF", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("MainWindow", "STDP", Q_NULLPTR));
        pushButton_6->setText(QApplication::translate("MainWindow", "FCU", Q_NULLPTR));
        pushButton_7->setText(QApplication::translate("MainWindow", "CCU", Q_NULLPTR));
        pbRfu->setText(QApplication::translate("MainWindow", "RFU", Q_NULLPTR));
        pbBBAT->setText(QApplication::translate("MainWindow", "BBAT", Q_NULLPTR));
        btnShutDown->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
