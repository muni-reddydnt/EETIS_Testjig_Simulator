/********************************************************************************
** Form generated from reading UI file 'rfu.ui'
**
** Created by: Qt User Interface Compiler version 5.9.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RFU_H
#define UI_RFU_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_rfu
{
public:
    QLabel *lblOPRMODE_2;
    QGroupBox *groupBox;
    QLabel *lblHarnessLED;
    QPushButton *pbHarness;
    QCheckBox *ckHarnessContinutyError;
    QLabel *label_103;
    QLabel *label_104;
    QLabel *label_105;
    QLabel *lblHarness;
    QWidget *widget_14;
    QLabel *lblFireLED;
    QLabel *lblBreechOpeningLED;
    QLabel *lblBreechClosingLED;
    QCheckBox *ckBDOBUSJ17J21;
    QCheckBox *ckBDOBUSJ19J23;
    QCheckBox *ckBDOBUSJ110J24;
    QCheckBox *ckCrossBDOBUSJ17J21;
    QCheckBox *ckCrossBDOBUSJ19J23;
    QCheckBox *ckCrossBDOBUSJ110J24;
    QLabel *label_108;
    QLabel *label_109;
    QLabel *label_110;
    QPushButton *pbHarness_2;
    QLabel *lblBDOBUSJ17J21;
    QLabel *lblBDOBUSJ19J23;
    QLabel *lblBDOBUSJ110J24;

    void setupUi(QWidget *rfu)
    {
        if (rfu->objectName().isEmpty())
            rfu->setObjectName(QStringLiteral("rfu"));
        rfu->resize(1900, 900);
        rfu->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));
        lblOPRMODE_2 = new QLabel(rfu);
        lblOPRMODE_2->setObjectName(QStringLiteral("lblOPRMODE_2"));
        lblOPRMODE_2->setGeometry(QRect(796, 30, 291, 55));
        QFont font;
        font.setFamily(QStringLiteral("Roboto"));
        font.setPointSize(25);
        font.setBold(true);
        font.setUnderline(true);
        font.setWeight(75);
        lblOPRMODE_2->setFont(font);
        lblOPRMODE_2->setStyleSheet(QLatin1String("\n"
"background:rgb(234, 236, 247);\n"
"\n"
"\n"
"color:rgb(53,74, 131);\n"
""));
        lblOPRMODE_2->setAlignment(Qt::AlignCenter);
        groupBox = new QGroupBox(rfu);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(476, 120, 931, 149));
        groupBox->setStyleSheet(QLatin1String("background:color rgb(150,160,186,40%);\n"
"border-radius:10px;"));
        lblHarnessLED = new QLabel(groupBox);
        lblHarnessLED->setObjectName(QStringLiteral("lblHarnessLED"));
        lblHarnessLED->setGeometry(QRect(519, 94, 30, 30));
        lblHarnessLED->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        pbHarness = new QPushButton(groupBox);
        pbHarness->setObjectName(QStringLiteral("pbHarness"));
        pbHarness->setGeometry(QRect(0, 0, 441, 41));
        QFont font1;
        font1.setPointSize(14);
        pbHarness->setFont(font1);
        pbHarness->setStyleSheet(QLatin1String("background-color: rgb(53, 74, 131); \n"
"color: rgb(255, 255, 255);"));
        ckHarnessContinutyError = new QCheckBox(groupBox);
        ckHarnessContinutyError->setObjectName(QStringLiteral("ckHarnessContinutyError"));
        ckHarnessContinutyError->setGeometry(QRect(672, 95, 31, 31));
        QFont font2;
        ckHarnessContinutyError->setFont(font2);
        ckHarnessContinutyError->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        label_103 = new QLabel(groupBox);
        label_103->setObjectName(QStringLiteral("label_103"));
        label_103->setGeometry(QRect(310, 42, 61, 38));
        QFont font3;
        font3.setFamily(QStringLiteral("Roboto"));
        font3.setPointSize(16);
        font3.setBold(true);
        font3.setWeight(75);
        label_103->setFont(font3);
        label_103->setStyleSheet(QLatin1String("background:color rgb(150,160,186,1%);\n"
"color:rgb(53,74, 131);"));
        label_104 = new QLabel(groupBox);
        label_104->setObjectName(QStringLiteral("label_104"));
        label_104->setGeometry(QRect(494, 44, 81, 33));
        label_104->setFont(font3);
        label_104->setStyleSheet(QLatin1String("background:color rgb(150,160,186,1%);\n"
"color:rgb(53,74, 131);"));
        label_104->setAlignment(Qt::AlignCenter);
        label_105 = new QLabel(groupBox);
        label_105->setObjectName(QStringLiteral("label_105"));
        label_105->setGeometry(QRect(582, 44, 211, 41));
        label_105->setFont(font3);
        label_105->setStyleSheet(QLatin1String("background:color rgb(150,160,186,1%);\n"
"color:rgb(53,74, 131);"));
        lblHarness = new QLabel(groupBox);
        lblHarness->setObjectName(QStringLiteral("lblHarness"));
        lblHarness->setGeometry(QRect(196, 90, 260, 40));
        QFont font4;
        font4.setFamily(QStringLiteral("Roboto"));
        font4.setPointSize(13);
        font4.setBold(true);
        font4.setWeight(75);
        lblHarness->setFont(font4);
        lblHarness->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblHarness->setAlignment(Qt::AlignCenter);
        widget_14 = new QWidget(rfu);
        widget_14->setObjectName(QStringLiteral("widget_14"));
        widget_14->setGeometry(QRect(110, 300, 1621, 381));
        widget_14->setStyleSheet(QLatin1String("background:color rgb(150,160,186,40%);\n"
"border-radius:10px;"));
        lblFireLED = new QLabel(widget_14);
        lblFireLED->setObjectName(QStringLiteral("lblFireLED"));
        lblFireLED->setGeometry(QRect(603, 160, 30, 30));
        lblFireLED->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        lblBreechOpeningLED = new QLabel(widget_14);
        lblBreechOpeningLED->setObjectName(QStringLiteral("lblBreechOpeningLED"));
        lblBreechOpeningLED->setGeometry(QRect(603, 236, 30, 30));
        lblBreechOpeningLED->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        lblBreechClosingLED = new QLabel(widget_14);
        lblBreechClosingLED->setObjectName(QStringLiteral("lblBreechClosingLED"));
        lblBreechClosingLED->setGeometry(QRect(603, 317, 30, 30));
        lblBreechClosingLED->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border-radius:15px;"));
        ckBDOBUSJ17J21 = new QCheckBox(widget_14);
        ckBDOBUSJ17J21->setObjectName(QStringLiteral("ckBDOBUSJ17J21"));
        ckBDOBUSJ17J21->setGeometry(QRect(726, 160, 31, 31));
        ckBDOBUSJ17J21->setFont(font2);
        ckBDOBUSJ17J21->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        ckBDOBUSJ19J23 = new QCheckBox(widget_14);
        ckBDOBUSJ19J23->setObjectName(QStringLiteral("ckBDOBUSJ19J23"));
        ckBDOBUSJ19J23->setGeometry(QRect(726, 236, 31, 31));
        ckBDOBUSJ19J23->setFont(font2);
        ckBDOBUSJ19J23->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        ckBDOBUSJ110J24 = new QCheckBox(widget_14);
        ckBDOBUSJ110J24->setObjectName(QStringLiteral("ckBDOBUSJ110J24"));
        ckBDOBUSJ110J24->setGeometry(QRect(726, 317, 31, 31));
        ckBDOBUSJ110J24->setFont(font2);
        ckBDOBUSJ110J24->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        ckCrossBDOBUSJ17J21 = new QCheckBox(widget_14);
        ckCrossBDOBUSJ17J21->setObjectName(QStringLiteral("ckCrossBDOBUSJ17J21"));
        ckCrossBDOBUSJ17J21->setGeometry(QRect(905, 160, 31, 31));
        ckCrossBDOBUSJ17J21->setFont(font2);
        ckCrossBDOBUSJ17J21->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        ckCrossBDOBUSJ19J23 = new QCheckBox(widget_14);
        ckCrossBDOBUSJ19J23->setObjectName(QStringLiteral("ckCrossBDOBUSJ19J23"));
        ckCrossBDOBUSJ19J23->setGeometry(QRect(905, 236, 31, 31));
        ckCrossBDOBUSJ19J23->setFont(font2);
        ckCrossBDOBUSJ19J23->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        ckCrossBDOBUSJ110J24 = new QCheckBox(widget_14);
        ckCrossBDOBUSJ110J24->setObjectName(QStringLiteral("ckCrossBDOBUSJ110J24"));
        ckCrossBDOBUSJ110J24->setGeometry(QRect(905, 317, 31, 31));
        ckCrossBDOBUSJ110J24->setFont(font2);
        ckCrossBDOBUSJ110J24->setStyleSheet(QLatin1String("QCheckBox {\n"
"    spacing: 18px; /* Adjust spacing between the checkbox and text */\n"
"    font-size: 28px; /* Set the font size */\n"
"    background-color: rgba(150, 160, 186, 1%); /* Background color */\n"
" color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator {\n"
"    width: 30px; /* Adjust the width of the checkbox indicator */\n"
"    height: 30px; /* Adjust the height of the checkbox indicator */\n"
"    border-radius: 30px; /* Make the indicator circular */\n"
"    border: 2px solid #cccccc; /* Add a border around the indicator */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"    background-color: #000000; /* Change the background color of the indicator when checked */\n"
"    border: 2px solid #ffffff; /* Add a border around the indicator when checked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
"\n"
"QCheckBox::indicator:unchecked {\n"
"    background-color: #ffffff; /* Change the background color of the indicator when unchecked */\n"
"color:rgb(53,74, 131);\n"
"}\n"
""));
        label_108 = new QLabel(widget_14);
        label_108->setObjectName(QStringLiteral("label_108"));
        label_108->setGeometry(QRect(579, 73, 81, 38));
        label_108->setFont(font3);
        label_108->setStyleSheet(QLatin1String("background:color rgb(150,160,186,1%);\n"
"color:rgb(53,74, 131);"));
        label_108->setAlignment(Qt::AlignCenter);
        label_109 = new QLabel(widget_14);
        label_109->setObjectName(QStringLiteral("label_109"));
        label_109->setGeometry(QRect(685, 70, 121, 61));
        label_109->setFont(font3);
        label_109->setStyleSheet(QLatin1String("background:color rgb(150,160,186,0%);\n"
"color:rgb(53,74, 131);"));
        label_109->setAlignment(Qt::AlignCenter);
        label_110 = new QLabel(widget_14);
        label_110->setObjectName(QStringLiteral("label_110"));
        label_110->setGeometry(QRect(820, 64, 201, 71));
        label_110->setFont(font3);
        label_110->setStyleSheet(QLatin1String("background:color rgb(150,160,186,1%);\n"
"color:rgb(53,74, 131);"));
        label_110->setAlignment(Qt::AlignCenter);
        pbHarness_2 = new QPushButton(widget_14);
        pbHarness_2->setObjectName(QStringLiteral("pbHarness_2"));
        pbHarness_2->setGeometry(QRect(0, 6, 321, 41));
        pbHarness_2->setFont(font1);
        pbHarness_2->setStyleSheet(QLatin1String("background-color: rgb(53, 74, 131); \n"
"color: rgb(255, 255, 255);"));
        lblBDOBUSJ17J21 = new QLabel(widget_14);
        lblBDOBUSJ17J21->setObjectName(QStringLiteral("lblBDOBUSJ17J21"));
        lblBDOBUSJ17J21->setGeometry(QRect(290, 155, 260, 40));
        lblBDOBUSJ17J21->setFont(font4);
        lblBDOBUSJ17J21->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBDOBUSJ17J21->setAlignment(Qt::AlignCenter);
        lblBDOBUSJ19J23 = new QLabel(widget_14);
        lblBDOBUSJ19J23->setObjectName(QStringLiteral("lblBDOBUSJ19J23"));
        lblBDOBUSJ19J23->setGeometry(QRect(290, 232, 260, 40));
        lblBDOBUSJ19J23->setFont(font4);
        lblBDOBUSJ19J23->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBDOBUSJ19J23->setAlignment(Qt::AlignCenter);
        lblBDOBUSJ110J24 = new QLabel(widget_14);
        lblBDOBUSJ110J24->setObjectName(QStringLiteral("lblBDOBUSJ110J24"));
        lblBDOBUSJ110J24->setGeometry(QRect(290, 312, 260, 40));
        lblBDOBUSJ110J24->setFont(font4);
        lblBDOBUSJ110J24->setStyleSheet(QLatin1String("background:rgb(234, 236, 247);\n"
"border: 4px solid rgb(53,74, 131);\n"
"color:rgb(53,74, 131);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        lblBDOBUSJ110J24->setAlignment(Qt::AlignCenter);

        retranslateUi(rfu);

        QMetaObject::connectSlotsByName(rfu);
    } // setupUi

    void retranslateUi(QWidget *rfu)
    {
        rfu->setWindowTitle(QApplication::translate("rfu", "Form", Q_NULLPTR));
        lblOPRMODE_2->setText(QApplication::translate("rfu", "RFU", Q_NULLPTR));
        groupBox->setTitle(QString());
        lblHarnessLED->setText(QString());
        pbHarness->setText(QApplication::translate("rfu", "BDOBUS Harness Check connection", Q_NULLPTR));
        ckHarnessContinutyError->setText(QString());
        label_103->setText(QApplication::translate("rfu", "DI's", Q_NULLPTR));
        label_104->setText(QApplication::translate("rfu", "DO's", Q_NULLPTR));
        label_105->setText(QApplication::translate("rfu", "Continuty Error", Q_NULLPTR));
        lblHarness->setText(QApplication::translate("rfu", "Harness", Q_NULLPTR));
        lblFireLED->setText(QString());
        lblBreechOpeningLED->setText(QString());
        lblBreechClosingLED->setText(QString());
        ckBDOBUSJ17J21->setText(QString());
        ckBDOBUSJ19J23->setText(QString());
        ckBDOBUSJ110J24->setText(QString());
        ckCrossBDOBUSJ17J21->setText(QString());
        ckCrossBDOBUSJ19J23->setText(QString());
        ckCrossBDOBUSJ110J24->setText(QString());
        label_108->setText(QApplication::translate("rfu", "DO's", Q_NULLPTR));
        label_109->setText(QApplication::translate("rfu", "Continuty\n"
" Error", Q_NULLPTR));
        label_110->setText(QApplication::translate("rfu", "Cross Continuty\n"
"Error", Q_NULLPTR));
        pbHarness_2->setText(QApplication::translate("rfu", "Continuty", Q_NULLPTR));
        lblBDOBUSJ17J21->setText(QApplication::translate("rfu", "FIRE", Q_NULLPTR));
        lblBDOBUSJ19J23->setText(QApplication::translate("rfu", "BREECH OPENING ", Q_NULLPTR));
        lblBDOBUSJ110J24->setText(QApplication::translate("rfu", "BREECH CLOSING ", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class rfu: public Ui_rfu {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RFU_H
